#pragma once

typedef void (* log_fp)(const char *text);

extern void set_log_property(const char *log_file_name, int max_file_size = 10000000, log_fp fp = NULL);
extern void log(const char *format, ...);

