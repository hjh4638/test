// vfw_testDlg.cpp : implementation file
//

#include "stdafx.h"
#include "vfw_test.h"
#include "vfw_testDlg.h"
#include "CamVfw.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CCamVfw	*vfw = NULL;

int message(const char *message, int message_len)
{
	return 0;
}


/////////////////////////////////////////////////////////////////////////////
// CVfw_testDlg dialog

CVfw_testDlg::CVfw_testDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CVfw_testDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CVfw_testDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CVfw_testDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CVfw_testDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CVfw_testDlg, CDialog)
	//{{AFX_MSG_MAP(CVfw_testDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDB_SETTING, OnSetting)
	ON_BN_CLICKED(IDB_SETTING2, OnSetting2)
	ON_BN_CLICKED(IDB_SETTING3, OnSetting3)
	//}}AFX_MSG_MAP
	ON_WM_DESTROY()
	ON_WM_TIMER()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVfw_testDlg message handlers

BOOL CVfw_testDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	vfw = new CCamVfw (m_hWnd, 1111);
	
	SetTimer (1000, 33, NULL);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CVfw_testDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CVfw_testDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CVfw_testDlg::OnDestroy()
{
	CDialog::OnDestroy();

	// TODO: Add your message handler code here
	delete vfw;
}

void CVfw_testDlg::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: Add your message handler code here and/or call default
	vfw->CaptureImage ();

	unsigned char *img;
	BITMAPINFO *bi;

	img = vfw->GetImage ();
	bi = vfw->GetBitmapInfo ();

	int dx = bi->bmiHeader.biWidth;
	int dy = ::abs(bi->bmiHeader.biHeight);

	if (IsWindowVisible ()) {
		CDC *dc = GetDC ();
		::SetDIBitsToDevice (dc->GetSafeHdc(), 0, 0, dx, dy, 0, 0, 0, dy, img, bi, DIB_RGB_COLORS);
		DrawCrossLine (dx/2, dy/2);
		ReleaseDC (dc);
	}

	CDialog::OnTimer(nIDEvent);
}

void CVfw_testDlg::DrawCrossLine (int cx, int cy)
{
	CDC *dc = GetDC ();

	CPen pen, *pOldPen;
	pen.CreatePen (PS_SOLID, 1, RGB(255,255,255));
	pOldPen = dc->SelectObject(&pen);

	dc->MoveTo (cx-50, cy);
	dc->LineTo (cx+50, cy);

	dc->MoveTo (cx, cy-50);
	dc->LineTo (cx, cy+50);

	dc->SelectObject(pOldPen);
	ReleaseDC (dc);
}

void CVfw_testDlg::OnSetting() 
{
	vfw->ViewCameraControl (m_hWnd, 0);
}

void CVfw_testDlg::OnSetting2() 
{
	vfw->ViewCameraControl (m_hWnd, 1);
}

void CVfw_testDlg::OnSetting3() 
{
	vfw->ViewCameraControl (m_hWnd, 2);
}
