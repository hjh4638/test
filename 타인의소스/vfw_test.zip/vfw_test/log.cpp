#include "stdafx.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/timeb.h>
#include <time.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <Windows.h>
#include "log.h"

static int max_file_size = 10000000;
static char log_file_name[256+1] = "log.txt";
static log_fp external_log_fp = NULL;

void _limit_file_size(char *file)
{
	struct stat buf[1];

	if(0 <= stat(file,buf)){					// ������ ���¸� �о��
		if(buf->st_size > max_file_size){		// ������ ���Ѱ��� �Ѿ ��
			char file_name_old[256];

			strcpy(file_name_old, file);
			strcat(file_name_old, ".old");			// .old �����̸� ����
			
			remove(file_name_old);					// .old ������ �����ϸ� ����
			rename(file,file_name_old);				// .old ���Ϸ� ����
		}
	}
}

static int _get_current_time(char *text, int len)
{
	struct _timeb timebuffer;
	struct tm tt;

	_ftime( &timebuffer );
	tt = *localtime(&timebuffer.time);

	return _snprintf (text, len, "%02d:%02d:%02d.%03d ", 
		(int)tt.tm_hour, (int)tt.tm_min, (int)tt.tm_sec, (int)timebuffer.millitm);
}

void set_log_property(const char *_log_file_name, int _max_file_size, log_fp _fp)
{
	strncpy(log_file_name, _log_file_name, 256);
	log_file_name[256] = '\0';
	max_file_size = _max_file_size;
	external_log_fp = _fp;

	_limit_file_size(log_file_name);
}

void log(const char *format, ...)
{
	int n = 0;
    va_list arg_list;
	char log_text[1024+1];

	_limit_file_size(log_file_name);

	n += _get_current_time(log_text+n, 1024-n);
	va_start (arg_list,format);
	n += _vsnprintf (log_text+n, 1024-n, format, arg_list);
	va_end (arg_list);
	n += _snprintf (log_text+n, 1024-n, "\r\n");
	log_text[1024] = '\0';

	if (external_log_fp) {
		(*external_log_fp) (log_text);
	}

	FILE *fp = fopen (log_file_name, "ab");
	if(fp){
		fputs (log_text, fp);
		fclose(fp);
	}
}

