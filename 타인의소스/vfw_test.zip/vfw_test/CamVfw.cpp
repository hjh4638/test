
#pragma comment (lib,"Vfw32.lib")

#include "stdafx.h"
#include "CamVfw.h"

CCamVfw::CCamVfw (HWND hWndParent, int id)
{
	m_hWnd = NULL;

	CreateCaptureView (hWndParent, id);
}

CCamVfw::~CCamVfw ()
{
	DestroyCaptureView ();

}

LRESULT CALLBACK CCamVfw::OnStatusMessageCallBack(HWND hwnd, int nID, LPCSTR lpszStatusText)
{
	return 0L;
}

LRESULT CALLBACK CCamVfw::OnErrorMessageCallBack(HWND hwnd, int nID, LPCSTR lpszErrorText)
{
	return 0L;
}

LRESULT CALLBACK CCamVfw::OnVideoCallbackProc(HWND hWnd, LPVIDEOHDR lpVHdr)
{
	return 0L;
}

LRESULT CALLBACK CCamVfw::OnFrameCallbackProc(HWND hWnd, LPVIDEOHDR lpVHdr)
{
	if (lpVHdr == NULL) {
		return 0;
	}
	CCamVfw *pVfw = (CCamVfw *)GetWindowLong (hWnd, GWL_USERDATA);
	return pVfw->OnCapture (lpVHdr);
}

LRESULT CALLBACK CCamVfw::OnYieldCallback(HWND hWnd)
{
//	return TRUE;

	MSG msg;

	while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
		if (msg.message == WM_QUIT) {
            return TRUE;
		}
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return TRUE;
}

int CCamVfw::OnCapture(LPVIDEOHDR lpVHdr)
{
	if (m_bitmapInfo.bmiHeader.biCompression == BI_RGB) {
		unsigned int img_size = 
			m_bitmapInfo.bmiHeader.biWidth * 
			m_bitmapInfo.bmiHeader.biHeight * 
			m_bitmapInfo.bmiHeader.biBitCount / 8;
		// assert (lpVHdr->dwBytesUsed == img_size);

		ReallocateImageBuffer (img_size);
		memcpy (m_pImageBuffer, lpVHdr->lpData, img_size);
	}
	return 0;
}

void CCamVfw::SetCaptureView (HWND hWnd)
{
	// Find out what the driver can do
	CAPSTATUS capStatus;
	CAPDRIVERCAPS capDriverCaps;	// VFW structures

	if (!capDriverGetCaps (hWnd, &capDriverCaps, sizeof (capDriverCaps))) {
		memset (&capDriverCaps, 0, sizeof (capDriverCaps));
		memset (&capStatus, 0, sizeof (capStatus));                                                     
	}
	// capDriverCaps.fHasOverlay=TRUE; 
	
	// Retrieve the default capture settings
	CAPTUREPARMS captureParms;	
	capCaptureGetSetup (hWnd, &captureParms, sizeof (captureParms));
	
	// set frame rate
	captureParms.wNumVideoRequested = 4; 
	captureParms.dwRequestMicroSecPerFrame=1000000/30;
	captureParms.vKeyAbort = 27; 
	captureParms.wNumAudioRequested = 4; 
	captureParms.fYield = FALSE;
	captureParms.fCaptureAudio = FALSE;
	captureParms.fAbortLeftMouse = TRUE;
	captureParms.fAbortRightMouse = TRUE;
	captureParms.fMakeUserHitOKToCapture=FALSE; 

	
	// Configure capture property
	BOOL ret = capCaptureSetSetup (hWnd, &captureParms, sizeof (captureParms));
	
	// Scale Preview window to the parent one
	//capPreviewScale (hWnd, (capStatus.fScale = TRUE));  // Scale preview to the window
	//SetWindowPos (hWnd, NULL, 0, 0, 320, 240, SWP_NOZORDER);
	
	// Set call backs
	capSetCallbackOnStatus (hWnd, OnStatusMessageCallBack); 
	capSetCallbackOnError (hWnd, OnErrorMessageCallBack);
	capSetCallbackOnVideoStream (hWnd, OnVideoCallbackProc);
	capSetCallbackOnFrame (hWnd, OnFrameCallbackProc);
	//capSetCallbackOnWaveStream (hWnd, OnWaveStreamCallback);
	capSetCallbackOnYield (hWnd, OnYieldCallback);
	
	// Set captured video format for Debug/Output/Draw
	capGetVideoFormat(hWnd, &m_bitmapInfo, sizeof(BITMAPINFO));

/*
	m_bitmapInfo.bmiHeader.biWidth = m_imgWidth;	
	m_bitmapInfo.bmiHeader.biHeight = m_imgHeight;
	capSetVideoFormat(hWnd, &m_bitmapInfo, sizeof(m_bitmapInfo));
*/
	// Set the preview rate to CAPTURE_INTVL_NORMAL milliseconds
	capPreviewRate (hWnd, 33);
	capPreviewScale (hWnd, FALSE);
	capPreview (hWnd, FALSE);
	capOverlay (hWnd, FALSE); 
}

int CCamVfw::CreateCaptureView (HWND hWndParent, int id)
{
	m_hWnd = capCreateCaptureWindow ("Web Cam", WS_CHILD | WS_VISIBLE, 
		0, 0, 320, 240, hWndParent, id);
	if (m_hWnd == NULL) {
		return -1;
	}
	
    // Connect to the next available driver
    for (int i=0; i<10; i++) {
        if (capDriverConnect (m_hWnd, i)) {
			char szDeviceName[80];
			char szDeviceVersion[80]; 

			capGetDriverDescription (i, szDeviceName, sizeof(szDeviceName), szDeviceVersion, sizeof(szDeviceVersion)); 

			SetWindowLong (m_hWnd, GWL_USERDATA, (long)this);
			SetCaptureView (m_hWnd);
            return id;
		}
	}
	::DestroyWindow (m_hWnd);
	return -1;
}

int CCamVfw::DestroyCaptureView ()
{
    if (m_hWnd != NULL) {
		capCaptureAbort(m_hWnd);

		capSetCallbackOnStatus (m_hWnd, NULL); 
		capSetCallbackOnError (m_hWnd, NULL);
		capSetCallbackOnVideoStream (m_hWnd, NULL);
		capSetCallbackOnFrame (m_hWnd, NULL);
		//capSetCallbackOnWaveStream (m_hWnd, NULL);
		capSetCallbackOnYield (m_hWnd, NULL);

		capDriverDisconnect(m_hWnd);
		::DestroyWindow (m_hWnd);
	}
	return 0;
}

int CCamVfw::CaptureImage ()
{
	//return capGrabFrameNoStop(m_hWnd);
	return capGrabFrame(m_hWnd);
}

void CCamVfw::ViewCameraControl (HWND hWnd, int opt)
{
	CAPDRIVERCAPS capDriverCaps;	// VFW structures

	capDriverGetCaps(m_hWnd, &capDriverCaps, sizeof (CAPDRIVERCAPS)); 

	if (opt == 0) {
		// Video source dialog box. 
		if (capDriverCaps.fHasDlgVideoSource) {
			capDlgVideoSource(m_hWnd); 
		}
	}
	else if (opt == 1) {
		// Video format dialog box. 
		if (capDriverCaps.fHasDlgVideoFormat) {
			capDlgVideoFormat(m_hWnd); 

			// Are there new image dimensions?
			CAPSTATUS capStatus;
			capGetStatus(m_hWnd, &capStatus, sizeof (CAPSTATUS));

			// If so, notify the parent of a size change.
		} 
	}
	else if (opt == 2) {
		// Video display dialog box. 
		if (capDriverCaps.fHasDlgVideoDisplay) {
			capDlgVideoDisplay(m_hWnd); 
		}
	}
}
