#pragma once

#include <windows.h>

class CCamBase {
protected:
	BITMAPINFO m_bitmapInfo;
	unsigned char *m_pImageBuffer;
	int m_iImageBufferSize;

	bool ReallocateImageBuffer (int size)
	{
		if (m_iImageBufferSize < size) {
			delete [] m_pImageBuffer;
			m_pImageBuffer = new unsigned char [size];
			m_iImageBufferSize = size;
			return true;
		}
		return false;
	}

public:
	CCamBase () 
	{ 
		memset (&m_bitmapInfo, 0, sizeof(BITMAPINFO));
		m_pImageBuffer = new unsigned char [1];
		m_iImageBufferSize = 1;
	}

	virtual ~CCamBase () 
	{
		delete [] m_pImageBuffer;
	}

	virtual int CaptureImage () 
	{ 
		return -1; 
	}

	virtual int DrawImage (HDC dc, int sx, int sy)
	{
		int dx = m_bitmapInfo.bmiHeader.biWidth;
		int dy = ::abs(m_bitmapInfo.bmiHeader.biHeight);
		return ::SetDIBitsToDevice (dc, sx, sy, dx, dy, 0, 0, 0, dy, m_pImageBuffer, &m_bitmapInfo, DIB_RGB_COLORS);
	}

	virtual unsigned char *GetImage ()
	{
		return m_pImageBuffer;
	}

	virtual BITMAPINFO *GetBitmapInfo ()
	{
		return &m_bitmapInfo;
	}
	virtual void ViewCameraControl (HWND hWnd = NULL, int opt = 0) 
	{ 
	}

	void InitBitmapInfo (int img_width, int img_height, int pixel_bytes)
	{
		memset( &m_bitmapInfo, 0, sizeof( BITMAPINFO ) );
		
		m_bitmapInfo.bmiHeader.biSize          = sizeof( BITMAPINFOHEADER );
		m_bitmapInfo.bmiHeader.biWidth         = img_width;
		m_bitmapInfo.bmiHeader.biHeight        = img_height; // top-down bitmap, negative height
		m_bitmapInfo.bmiHeader.biPlanes        = 1;
		m_bitmapInfo.bmiHeader.biBitCount      = pixel_bytes*8;
		m_bitmapInfo.bmiHeader.biCompression   = BI_RGB;
		m_bitmapInfo.bmiHeader.biSizeImage     = img_width*img_height*pixel_bytes;
		m_bitmapInfo.bmiHeader.biXPelsPerMeter = 100;
		m_bitmapInfo.bmiHeader.biYPelsPerMeter = 100;
		m_bitmapInfo.bmiHeader.biClrUsed       = 0;
		m_bitmapInfo.bmiHeader.biClrImportant  = 0;
	}
};

