#pragma once

#include <afxwin.h>
#include <vfw.h>
#include "CamBase.h"

class CCamVfw : public CCamBase
{
private:
    HWND m_hWnd;

	static LRESULT CALLBACK OnStatusMessageCallBack(HWND hwnd, int nID, LPCSTR lpszStatusText);
	static LRESULT CALLBACK OnErrorMessageCallBack(HWND hwnd, int nID, LPCSTR lpszErrorText);
	static LRESULT CALLBACK OnVideoCallbackProc(HWND hWnd, LPVIDEOHDR lpVHdr);
	static LRESULT CALLBACK OnFrameCallbackProc(HWND hWnd, LPVIDEOHDR lpVHdr);
	static LRESULT CALLBACK OnYieldCallback(HWND hWnd);

	void SetCaptureView (HWND hWnd);
	int CreateCaptureView (HWND hWndParent, int id);
	int DestroyCaptureView ();
	int OnCapture (LPVIDEOHDR lpVHdr);

public:
	CCamVfw (HWND hWndParent, int id);
	virtual ~CCamVfw ();

	virtual int CaptureImage ();

	virtual void ViewCameraControl (HWND hWnd = NULL, int opt = 0);
};

