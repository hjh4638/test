// webcamDlg.cpp : implementation file
//

#include "stdafx.h"
#include "webcam.h"
#include "webcamDlg.h"
#include "camsetting.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define CLIP(x) (((x) <0)?0:(((x)>255)?255:(x)))
#define RED		0
#define GREEN	1
#define BLUE	2

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWebcamDlg dialog

CWebcamDlg::CWebcamDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CWebcamDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CWebcamDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CWebcamDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWebcamDlg)
	DDX_Control(pDX, IDC_CAM, m_Cam);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CWebcamDlg, CDialog)
	//{{AFX_MSG_MAP(CWebcamDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_SETTING, OnSetting)
	ON_BN_CLICKED(IDC_CAPTURE, OnCapture)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWebcamDlg message handlers

BOOL CWebcamDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	m_strErrMsg = "";

	m_hCamWnd = capCreateCaptureWindow( "Capture Window", WS_CHILD | WS_VISIBLE, 5, 5, 320, 240, m_Cam, NULL);

	// call the WM_CAP_DRIVER_CONNECT
	// ��ġ�� ����̽��� ������ 0 ~ 9������ ī�޶� ���� �� �� �ִ�.
	// ������ > ī�޶� �� ���ɳʿ� �ݵ�� 1�� �̻��� ī�޶� ��ġ �Ǿ� �־�� �Ѵ�.
	if(!capDriverConnect(m_hCamWnd, 0)) {
		m_strErrMsg = "Error #001 : the specified capture driver cannot be connected to the capture window.";		
	} 

	// ���� ����̹� ������ ���� ���� ������
	else if(!capDriverGetCaps(m_hCamWnd, &m_psCapsInfo, sizeof(m_psCapsInfo))) {
		m_strErrMsg = "Error #006 : the capture window is not connected to a capture driver.";

	}else{
		if(m_psCapsInfo.fHasDlgVideoFormat) {
			if(!capDlgVideoFormat(m_hCamWnd)) {
				m_strErrMsg = "Error #007: Video Format Dialog Error";
			}
		}

		// m_psCapsInfo.fHasOverlay���� overlay�� ������ ���� ������(=0) ��� �� �� ����.
		if(m_psCapsInfo.fHasOverlay) {
			if(!capOverlay(m_hCamWnd, FALSE)) {
				m_strErrMsg = "Error #004 : Overlay fail";
			}
		}
	
		// 1/1000 ������ ������ ��µȴ�.
		if(!capPreviewRate(m_hCamWnd, 1)) {
			m_strErrMsg = "Error #002 : the capture window is not connected to a capture driver.";
		}

		if(!capPreview(m_hCamWnd, TRUE)) {
			m_strErrMsg = "Error #005 : the Preview is failed.";
		}

	}

	// �����޽��� ����
	if(m_strErrMsg.GetLength() != 0) {
		MessageBox(m_strErrMsg);
	}

	CAPTUREPARMS cp;     
	
	capCaptureGetSetup(m_hCamWnd, &cp, sizeof(cp) );	// get the current defaults      
	
	cp.dwRequestMicroSecPerFrame = 1;					// Set desired frame rate     
	cp.fMakeUserHitOKToCapture   = FALSE;
	cp.fYield                    = TRUE;                // we want capture on a background thread.
	cp.wNumVideoRequested        = (WORD) 1;			// we may get less than this - no problem
	cp.fCaptureAudio             = FALSE;     
	cp.vKeyAbort                 = 0;                   // If no key is provided, it won't stop...
	cp.fAbortLeftMouse           = FALSE;
	cp.fAbortRightMouse          = FALSE;
	cp.fLimitEnabled             = FALSE;				// we want to stop     
	cp.fMCIControl               = FALSE;
	
	capCaptureSetSetup(m_hCamWnd, &cp, sizeof(cp) ); 

	capSetCallbackOnVideoStream(m_hCamWnd, VideoCallbackProc);
	capSetCallbackOnFrame(m_hCamWnd, VideoCallbackProc);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CWebcamDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CWebcamDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CWebcamDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CWebcamDlg::OnSetting() 
{
	// TODO: Add your control notification handler code here
	CCamSetting *pdlgCamSetting;
	pdlgCamSetting = NULL;

	pdlgCamSetting = new CCamSetting (this);
	pdlgCamSetting->m_hCamWnd = m_hCamWnd;

	ASSERT( pdlgCamSetting );
	pdlgCamSetting->Create( IDD_DIALOG_CAM_SETTING );

	pdlgCamSetting->ShowWindow( SW_SHOW );
}

void CWebcamDlg::OnCapture() 
{
	// TODO: Add your control notification handler code here
//	capFileSetCaptureFile(m_hCamWnd,"C:/capture.avi");

/*
	// �����ϴ� �ڵ�. ���� ������ �ϸ� Ŭ�����忡 ���� ������ ����. �������� �𸣰���.
	// �⺻������ C:\capture.avi�� ����. ������ ���� ����
	capCaptureSingleFrameOpen(m_hCamWnd);
	capCaptureSingleFrame(m_hCamWnd);
	capCaptureSingleFrameClose(m_hCamWnd);
	capEditCopy(m_hCamWnd);
*/

	// ���� ���� ����
	capGrabFrameNoStop(m_hCamWnd);

	// Ŭ�����忡 ����
	capEditCopy(m_hCamWnd);

	//DIV : Device Independent Bitmap
	if(!capFileSaveDIB(m_hCamWnd,"a.bmp"))
	{
		MessageBox("Capture Error");
	}

}
LRESULT CALLBACK CWebcamDlg::VideoCallbackProc(HWND hWnd, LPVIDEOHDR lpVHdr)
{
	unsigned int uiBuflen = lpVHdr->dwBufferLength;
	unsigned char RGB[240][360][3]={0,};
	unsigned int nWidth, nHeight;
	unsigned int i, j;
	int Y0, U, Y1, V;

//     The "YUY2" YUV pixel format looks like this: 
//         As a series of BYTES:    [Y0][U][Y1][V] (reverse it for a DWORD) 
//
//     As you can see, both formats pack two pixels into a single DWORD.
//     The pixels share U and V components and have separate Y components. 

	nWidth = 320;
	nHeight = 240;

	// YUY2 ---> RGB
	for(j = 0; j < nHeight; j ++) {	// height
		for(i = 0; i < nWidth; i += 2 ) {	//width
			

			Y0 =	lpVHdr->lpData[(nWidth*j + i) * 2];
			U  =	lpVHdr->lpData[(nWidth*j + i) * 2 + 1];
			Y1 =	lpVHdr->lpData[(nWidth*j + i) * 2 + 2];
			V  =	lpVHdr->lpData[(nWidth*j + i) * 2 + 3];

			RGB[j][i][RED] = (int) CLIP( Y0 + (1.4075*(V-128)));
			RGB[j][i][GREEN] = (int) CLIP( Y0 - 0.3455*(U-128) - 0.7169*(V-128));
			RGB[j][i][BLUE] = (int) CLIP( Y0 + 1.7790*(U-128));

			RGB[j][i+1][RED] = (int) CLIP( Y1 + (1.4075*(V-128)));
			RGB[j][i+1][GREEN] = (int) CLIP( Y1 - 0.3455*(U-128) - 0.7169*(V-128));
			RGB[j][i+1][BLUE] = (int) CLIP( Y1 + 1.7790*(U-128));
		}
	}

	// RGB���� ����
	int nMargin = 20;
	for(j = 0; j < nHeight; j ++) {	// height
		for(i = 0; i < nWidth; i ++) {	//width
			if( ((j > nMargin)&&(j <nHeight - nMargin )&& i == nMargin)					// ������
				|| ((j > nMargin)&&(j < nHeight - nMargin )&& i == nWidth - nMargin)	// ������
				|| ((i > nMargin)&&(i < nWidth - nMargin )&& j == nMargin)				// ���
				|| ((i > nMargin)&&(i < nWidth - nMargin )&& j == nHeight - nMargin)	// �ϴ�
				)
			{
				RGB[j][i][RED] = 0xff;
				RGB[j][i][GREEN] = 0x00;
				RGB[j][i][BLUE] = 0x00;
			}
		}
	}

	// RGB ---> YUY2
	for(j = 0; j < nHeight; j ++) {	// height
		for(i = 0; i < nWidth; i += 2 ) {	//width
			Y0 = (int) CLIP(0.2999*RGB[j][i][RED] + 0.587*RGB[j][i][GREEN] + 0.114*RGB[j][i][BLUE]);
			Y1 = (int) CLIP(0.2999*RGB[j][i+1][RED] + 0.587*RGB[j][i+1][GREEN] + 0.114*RGB[j][i+1][BLUE]);
			U  = (int) CLIP(-0.1687*RGB[j][i][RED] - 0.3313*RGB[j][i][GREEN] +0.5*RGB[j][i][BLUE] + 128.0);
			V  = (int) CLIP( 0.5*RGB[j][i][RED] - 0.4187*RGB[j][i][GREEN] - 0.0813*RGB[j][i][BLUE] + 128.0);

			lpVHdr->lpData[(nWidth*j + i) * 2] = Y0;
			lpVHdr->lpData[(nWidth*j + i) * 2 + 1] = U;
			lpVHdr->lpData[(nWidth*j + i) * 2 + 2] = Y1;
			lpVHdr->lpData[(nWidth*j + i) * 2 + 3] = V;

		}
	}

	return (LRESULT) TRUE;
}