﻿namespace audioProcessing
{
    partial class serialForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.confirmBtn = new System.Windows.Forms.Button();
            this.comboPort = new System.Windows.Forms.ComboBox();
            this.comboBaud = new System.Windows.Forms.ComboBox();
            this.comboData = new System.Windows.Forms.ComboBox();
            this.comboParity = new System.Windows.Forms.ComboBox();
            this.comboStop = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "포트";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "속도";
            // 
            // confirmBtn
            // 
            this.confirmBtn.Location = new System.Drawing.Point(232, 67);
            this.confirmBtn.Name = "confirmBtn";
            this.confirmBtn.Size = new System.Drawing.Size(75, 23);
            this.confirmBtn.TabIndex = 6;
            this.confirmBtn.Text = "확인";
            this.confirmBtn.UseVisualStyleBackColor = true;
            this.confirmBtn.Click += new System.EventHandler(this.confirmBtn_Click);
            // 
            // comboPort
            // 
            this.comboPort.FormattingEnabled = true;
            this.comboPort.Location = new System.Drawing.Point(186, 15);
            this.comboPort.Name = "comboPort";
            this.comboPort.Size = new System.Drawing.Size(121, 20);
            this.comboPort.TabIndex = 7;
            // 
            // comboBaud
            // 
            this.comboBaud.FormattingEnabled = true;
            this.comboBaud.Items.AddRange(new object[] {
            "9600",
            "19200",
            "57600"});
            this.comboBaud.Location = new System.Drawing.Point(186, 41);
            this.comboBaud.Name = "comboBaud";
            this.comboBaud.Size = new System.Drawing.Size(121, 20);
            this.comboBaud.TabIndex = 8;
            this.comboBaud.Text = "57600";
            // 
            // comboData
            // 
            this.comboData.FormattingEnabled = true;
            this.comboData.Items.AddRange(new object[] {
            "7",
            "8"});
            this.comboData.Location = new System.Drawing.Point(-89, 125);
            this.comboData.Name = "comboData";
            this.comboData.Size = new System.Drawing.Size(99, 20);
            this.comboData.TabIndex = 9;
            this.comboData.Text = "8";
            // 
            // comboParity
            // 
            this.comboParity.FormattingEnabled = true;
            this.comboParity.Items.AddRange(new object[] {
            "None",
            "Odd",
            "Even"});
            this.comboParity.Location = new System.Drawing.Point(-89, 125);
            this.comboParity.Name = "comboParity";
            this.comboParity.Size = new System.Drawing.Size(99, 20);
            this.comboParity.TabIndex = 10;
            this.comboParity.Text = "None";
            // 
            // comboStop
            // 
            this.comboStop.FormattingEnabled = true;
            this.comboStop.Items.AddRange(new object[] {
            "1",
            "2"});
            this.comboStop.Location = new System.Drawing.Point(-89, 125);
            this.comboStop.Name = "comboStop";
            this.comboStop.Size = new System.Drawing.Size(99, 20);
            this.comboStop.TabIndex = 11;
            this.comboStop.Text = "1";
            // 
            // serialForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(328, 101);
            this.Controls.Add(this.comboStop);
            this.Controls.Add(this.comboParity);
            this.Controls.Add(this.comboData);
            this.Controls.Add(this.comboBaud);
            this.Controls.Add(this.comboPort);
            this.Controls.Add(this.confirmBtn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "serialForm";
            this.Text = "시리얼 정보";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button confirmBtn;
        private System.Windows.Forms.ComboBox comboPort;
        private System.Windows.Forms.ComboBox comboBaud;
        private System.Windows.Forms.ComboBox comboData;
        private System.Windows.Forms.ComboBox comboParity;
        private System.Windows.Forms.ComboBox comboStop;
    }
}