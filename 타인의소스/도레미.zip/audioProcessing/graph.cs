﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace audioProcessing
{
    public partial class graph : UserControl
    {
        private int centerY = 75;
        private int _cursor = 0;

        private int _maxValue = 0;
        private int _minValue = 0;

        private Point[] rangeFFT;
        private Point[] rangePCM;
        private Point[] rangePCM2;

        private enum GMODE
        {
            PCM,
            FFT,
        }
        private GMODE SEL_MODE;
        public graph()
        {
            InitializeComponent();
            rangeFFT = new Point[600];
            rangePCM = new Point[600];
            rangePCM2 = new Point[600];
            for (int i = 0; i < 600; i++)
            {
                rangePCM2[i].X = i;
                rangePCM2[i].Y = centerY - 1;
                rangePCM[i].X = i;
                rangePCM[i].Y = centerY + 1;
            }
            
        }
        public void setData(int maxValue, int minValue)
        {
            _maxValue = maxValue;
            _minValue = minValue;
            SEL_MODE = GMODE.PCM;
            if (_cursor > 599)
            {
                _cursor = 0;
            }
            rangePCM[_cursor].X = _cursor;
            rangePCM[_cursor].Y = centerY + 1 + (int)(_maxValue * 2); // 이부분 수정하면 그래프 크기가 달라짐.
            rangePCM2[_cursor].X = _cursor;
            rangePCM2[_cursor].Y = centerY - 1 - (int)(_minValue * 2); // 이부분 수정하면 그래프 크기가 달라짐.

            _cursor++;

            this.Refresh();
        }
        public void setData(double[] range)
        {
            SEL_MODE = GMODE.FFT;
            for (int i = 0; i < 600; i++)
            {
                rangeFFT[i].X = i;
                rangeFFT[i].Y = 75 + -1 * (int)(range[i] * 75.0f / 100.0f);
            }
            this.Refresh();
        }
        private void graph_Paint(object sender, PaintEventArgs e)
        {     
            if (SEL_MODE == GMODE.PCM)
            {
                Pen p = new Pen(Color.Black, 2);
                Graphics G = e.Graphics;
                G.Clear(Color.White);
                G.DrawLines(p, rangePCM);
                G.DrawLines(p, rangePCM2);        
            }
            if (SEL_MODE == GMODE.FFT)
            {
                Pen p = new Pen(Color.Black, 2);
                Graphics G = e.Graphics;
                G.Clear(Color.White);
                G.DrawLines(p, rangeFFT);
            }
        }   
    }
}
