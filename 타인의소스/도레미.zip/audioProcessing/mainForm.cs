﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using NAudio.WindowsMediaFormat;
using NAudio.Wave;
using NAudio.Dsp;
using System.IO.Ports;

namespace audioProcessing
{
    public partial class mainForm : Form, serialFormMessage
    {
        private SerialPort serial;

        private WaveIn waveIn;
        private graph myGraph;
        private graph fftGraph;

        private double[] array = new double[1024];

        private string _portName; 
        private int _baudRate;
        private int _dataBits;
        private Parity _parityBit;
        private StopBits _stopBit;

        private FFT2 _fft;

        private bool isFind = false;
        public mainForm()
        {
            
            InitializeComponent();
            progressPower.Maximum = 100;
  
            int waveInDevices = WaveIn.DeviceCount;
            if (waveInDevices == 0)                         //마이크 있는지 확인
            {
                MessageBox.Show("마이크 연결을 확인해주세요");
                btnStart.Enabled = false;
                return ;
            }
            waveIn = new WaveIn();

            int logN = 10;
            int n = 1 << logN; // = 2^10
            
            _fft = new FFT2();
            _fft.init((uint)logN);

            waveIn.DataAvailable += waveIn_DataAvailable;   //마이크 입력 이벤트
            int sampleRate = 10240;                         // 10240 Hz
            int channels = 1;                               // mono
            waveIn.WaveFormat = new WaveFormat(sampleRate, channels);
            waveIn.StartRecording();                        // 마이크 입력 시작

            myGraph = new graph();
            myGraph.Left = 12;
            myGraph.Top = 12;

            fftGraph = new graph();
            fftGraph.Left = 12;
            fftGraph.Top = 164;
            
            this.Controls.Add(myGraph);                     // 그래프 객체 입력
            this.Controls.Add(fftGraph);                    // fft 그래프 객체 입력
        }
        private int _fftCount = 0;
        private int _powerCount = 0;
        private float maxValue = 0;
        private float minValue = 0;
        private double PI2N = 2.0f * Math.PI / 1024.0f;

        private int bigCount = 0;
        void waveIn_DataAvailable(object sender, WaveInEventArgs e)
        {
            for (int index = 0; index < e.BytesRecorded; index += 2)
            {
                short sample = (short)((e.Buffer[index + 1] << 8) | e.Buffer[index + 0]); // pcm data변경
                float sample32 = sample / 32768f;
                array[index / 2] = (sample32);           
                
                maxValue = Math.Max(maxValue, sample32);   
                minValue = Math.Min(minValue, sample32);
                    
                _powerCount++;
                _fftCount++;
                if (_fftCount == 1000)
                {
                    int logN = 10;
                    int n = 1 << logN;
                    double[] bigValue = {-100,-100,-100,-100,-100};
                    int[] bigValueIndexId = { 0, 0, 0, 0, 0 };
                    double[] ff = new double[n];
                    double[] re = new double[n];
                    double[] im = new double[n];
                    double[] xp = new double[n];

                    double[] sp = new double[n];

                    for (int i = 0; i < 1024; i++)
                    {
                        if (i < 2)
                        {
                            ff[i] = array[i]; 
                            continue;
                        }
                        ff[i] = (array[i - 2] + array[i - 1] + array[i])/3.0;
                    } // fir filter low pass filter 

                    for (int i = 0; i < 1024; i++)
                    {
                        re[i] = ff[i] * (0.54f - 0.46f * Math.Cos(PI2N * i));
                    }// hamming window
                    _fft.run(re, im); // fft 실행
                    for (int i = 0; i < 1024; i++)
                    {
                        sp[i] = re[i] * re[i] + im[i] * im[i] * 10;
                        xp[i] = re[i] * re[i] + im[i] * im[i];
                        xp[i] = (xp[i] == 0) ? -100.0f : 10.0f * Math.Log10(xp[i]);
                    } // 진폭 스팩트럼

                    fftGraph.setData(xp); //진폭 스펙트럼 값 그리기
                    _fftCount = 0;

                    if (isFind == false)
                    {
                        if (sp[52] > 30 && sp[53] > 30)
                        {
                            soundLabel.Text = "도도도 소리가 들립니다.";
                            if (serial != null)
                            {
                                serial.WriteLine("B");
                            }
                            isFind = true;
                            bigCount = 0;
                        }
                        else if (sp[58] > 10 && sp[59] > 10)
                        {
                            soundLabel.Text = "레레레 소리가 들립니다.";
                            if (serial != null)
                            {
                                serial.WriteLine("C");
                            }
                            isFind = true;
                            bigCount = 0;
                        }
                        else if (sp[47] > 2 && sp[95] > 2 && sp[94] > 2 && sp[116] > 2 &&
                            sp[117] > 2 && sp[142] > 2 && sp[143] > 2)
                        {
                            soundLabel.Text = "경적 소리가 들립니다.";
                            if (serial != null)
                            {
                                serial.WriteLine("A");
                            }
                            isFind = true;
                            bigCount = 0;
                        }
                    }
                    if(12 == bigCount++)
                    {
                        soundLabel.Text = "소리가 들리지 않습니다.";
                        isFind = false;
                    }
                }
                    
                if (_powerCount == 200)
                {
                    progressPower.Value = (int)(Math.Max(maxValue, -1 * minValue) * 100.0); // 실시간 파워 표시
                    myGraph.setData((int)(maxValue * 75.0),(int)(-1 * minValue * 75.0)); //실시간 입려 표시
                    minValue = 0;
                    maxValue = 0;
                    _powerCount = 0;
                }
            }
        }                                                   // 마이크 입력 이벤트 부분

        private void btnStart_Click(object sender, EventArgs e)
        {
            
        }
        private void btnSerial_Click(object sender, EventArgs e)
        {
            serialForm sf = new serialForm(this);
            sf.Show();
        }

        public void SetData(string _portName, int _baudRate, int _dataBits, Parity _parityBit, StopBits _stopBit)
        {
            this._portName = _portName;
            this._baudRate = _baudRate;
            this._dataBits = _dataBits;
            this._parityBit = _parityBit;
            this._stopBit = _stopBit;

            if (serial == null)
            {
                serial = new SerialPort(_portName, _baudRate, _parityBit, _dataBits, _stopBit);
                if (serial.IsOpen) serial.Close();
                serial.Open();
            }
            else
            { }
            //new Thread(new ThreadStart(serialThread)).Start();
        }
        public void serialThread()
        {
            if (serial == null)
            {
                serial = new SerialPort(_portName, _baudRate, _parityBit, _dataBits, _stopBit);
                if (serial.IsOpen) serial.Close();
                serial.Open();
            }
            else
            { }
        }

    }
    public interface serialFormMessage
    {
        void SetData(string _portName, int _baudRate, int _dataBits, Parity _parityBit, StopBits _stopBit);
    }

    public class FFT2
    {
        class FFTElement
        {
            public double re = 0.0;     
            public double im = 0.0;     
            public FFTElement next;     
            public uint revTgt;         
        }

        private uint m_logN = 0;         
        private uint m_N = 0;           
        private FFTElement[] m_X;       

        public FFT2()
        {
        }

        public void init( uint logN) // fft 초기화
        {
            m_logN = logN;
            m_N = (uint)(1 << (int)m_logN);

            m_X = new FFTElement[m_N];
            for (uint k = 0; k < m_N; k++)
                m_X[k] = new FFTElement();

            for (uint k = 0; k < m_N - 1; k++)
                m_X[k].next = m_X[k + 1];

            for (uint k = 0; k < m_N; k++)
                m_X[k].revTgt = BitReverse(k, logN);
        } 

        public void run(double[] xRe, double[] xIm ) // fft 실행
        {
            uint numFlies = m_N >> 1; 
            uint span = m_N >> 1;     
            uint spacing = m_N;         
            uint wIndexStep = 1;        

            FFTElement x = m_X[0];
            uint k = 0;
            double scale = 1.0;
            while (x != null)
            {
                x.re = scale * xRe[k];
                x.im = scale * xIm[k];
                x = x.next;
                k++;
            }

            for (uint stage = 0; stage < m_logN; stage++)
            {
                double wAngleInc = wIndexStep * 2.0 * Math.PI / m_N;
                wAngleInc *= -1;
                double wMulRe = Math.Cos(wAngleInc);
                double wMulIm = Math.Sin(wAngleInc);

                for (uint start = 0; start < m_N; start += spacing)
                {
                    FFTElement xTop = m_X[start];
                    FFTElement xBot = m_X[start + span];

                    double wRe = 1.0;
                    double wIm = 0.0;

                    for (uint flyCount = 0; flyCount < numFlies; ++flyCount)
                    {
                        double xTopRe = xTop.re;
                        double xTopIm = xTop.im;
                        double xBotRe = xBot.re;
                        double xBotIm = xBot.im;

                        xTop.re = xTopRe + xBotRe;
                        xTop.im = xTopIm + xBotIm;

                        xBotRe = xTopRe - xBotRe;
                        xBotIm = xTopIm - xBotIm;
                        xBot.re = xBotRe * wRe - xBotIm * wIm;
                        xBot.im = xBotRe * wIm + xBotIm * wRe;

                        xTop = xTop.next;
                        xBot = xBot.next;

                        double tRe = wRe;
                        wRe = wRe * wMulRe - wIm * wMulIm;
                        wIm = tRe * wMulIm + wIm * wMulRe;
                    }
                }

                numFlies >>= 1;   
                span >>= 1;
                spacing >>= 1;
                wIndexStep <<= 1;     
            }

            x = m_X[0];
            while (x != null)
            {
                uint target = x.revTgt;
                xRe[target] = x.re;
                xIm[target] = x.im;
                x = x.next;
            }
        }

        private uint BitReverse( uint x, uint numBits)
        {
            uint y = 0;
            for (uint i = 0; i < numBits; i++)
            {
                y <<= 1;
                y |= x & 0x0001;
                x >>= 1;
            }
            return y;
        }
    } 



}
