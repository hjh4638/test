﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;
namespace audioProcessing
{
    public partial class serialForm : Form
    {
        private serialFormMessage frm = null;
        private Parity _parity;
        public serialForm(serialFormMessage frm)
        {
            InitializeComponent();
            this.frm = frm;
            comboPort.Items.Clear();

            foreach (string item in System.IO.Ports.SerialPort.GetPortNames())
            {
                comboPort.Items.Add(item);
            }
        }

        private void confirmBtn_Click(object sender, EventArgs e)
        {
            switch (comboParity.Text)
            {
                case "None":
                    _parity = Parity.None;
                    break;
                case "Odd":
                    _parity = Parity.Odd;
                    break;
                case "Even":
                    _parity = Parity.Even;
                    break;
                default:
                    _parity = Parity.None;
                    break;
            }
            if (comboBaud.Text == "" || comboData.Text == "" || comboParity.Text == "" || comboPort.Text == "" || comboStop.Text == "")
            {
                MessageBox.Show("모두 입력해주세요");
            }
            else
            {
                this.frm.SetData(comboPort.Text, int.Parse(comboBaud.Text), int.Parse(comboData.Text), _parity, comboStop.Text == "1" ? StopBits.One : StopBits.None);//int.Parse(comboParity.Text), int.Parse(comboStop.Text));
                this.Close();
            }
        }
    }
}
