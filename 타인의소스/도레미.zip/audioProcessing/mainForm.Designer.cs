﻿namespace audioProcessing
{
    partial class mainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSerial = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.progressPower = new System.Windows.Forms.ProgressBar();
            this.soundLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnSerial
            // 
            this.btnSerial.Location = new System.Drawing.Point(508, 318);
            this.btnSerial.Name = "btnSerial";
            this.btnSerial.Size = new System.Drawing.Size(104, 42);
            this.btnSerial.TabIndex = 0;
            this.btnSerial.Text = "SERIAL";
            this.btnSerial.UseVisualStyleBackColor = true;
            this.btnSerial.Click += new System.EventHandler(this.btnSerial_Click);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(398, 318);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(104, 42);
            this.btnStart.TabIndex = 1;
            this.btnStart.Text = "START";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // progressPower
            // 
            this.progressPower.Location = new System.Drawing.Point(12, 320);
            this.progressPower.Maximum = 200;
            this.progressPower.Name = "progressPower";
            this.progressPower.Size = new System.Drawing.Size(380, 40);
            this.progressPower.TabIndex = 3;
            // 
            // soundLabel
            // 
            this.soundLabel.AutoSize = true;
            this.soundLabel.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.soundLabel.Location = new System.Drawing.Point(10, 376);
            this.soundLabel.Name = "soundLabel";
            this.soundLabel.Size = new System.Drawing.Size(137, 12);
            this.soundLabel.TabIndex = 4;
            this.soundLabel.Text = "소리가 들리지 않습니다.";
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(626, 397);
            this.Controls.Add(this.soundLabel);
            this.Controls.Add(this.progressPower);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.btnSerial);
            this.Name = "mainForm";
            this.Text = "음성처리";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSerial;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.ProgressBar progressPower;
        private System.Windows.Forms.Label soundLabel;
    }
}

