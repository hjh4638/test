﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.IO.Ports;
using OpenCvSharp;
/////////////////////////////////////////////////////////////////////////////////////////////////////
// Version : V_8.01
// update : 2013. 12. 29
/////////////////////////////////////////////////////////////////////////////////////////////////////

namespace StuffSystem
{
    public partial class StuffSystemForm : Form
    {
        public static List<Box> boxInfo = new List<Box>();              // 전체 box 기록
        public static List<Spare> afford_Layer1 = new List<Spare>();    // 여유공간 1층 기록
        public static List<Spare> afford_Layer2 = new List<Spare>();    // 여유공간 2층 기록

        public static bool checkEdge = false;
        public static bool flag = false;

        CvCapture capture;
        IplImage img = new IplImage(220, 165, BitDepth.U8, 0);
        IplImage img_canny;
        CvMemStorage storage;
        CvSeq lines;
        IplImage imgHough;
        bool edge = true;

        public string comport;
        public static SerialPort port;
        public static string recv = "";
        public static string test_recv = "9";
        public bool modeSet = false;
        public static bool[] mFlag = new bool[2] {false, false};
        public static int[] angle = new int[2];
        public int aCount = 0;
        public Thread t1, t2;

// ========================================== 초기설정 ==========================================
        public StuffSystemForm()
        {
            InitializeComponent();
            afford_Layer1.Add(new Spare(new Point(30, 1), 510));        // Layer1 초기 여유공간 설정
            afford_Layer2.Add(new Spare(new Point(30, 2), 510));        // Layer2 초기 여유공간 설정
        }
        private void pnl_Shelf_Paint(object sender, PaintEventArgs e)   // 선반 그리기
        {
            Graphics g = e.Graphics;
            SolidBrush brownbrush = new SolidBrush(Color.BurlyWood);
            SolidBrush whitebrush = new SolidBrush(Color.White);
            g.FillRectangle(brownbrush, 15, 15, 570, 270);
            g.FillRectangle(whitebrush, 30, 30, 540, 112);
            g.FillRectangle(whitebrush, 30, 158, 540, 112);
            //////////////////////////////////////////////////////////////////Spare space test
            Graphics g_space = this.pnl_Shelf.CreateGraphics();
            SolidBrush graybrush = new SolidBrush(Color.Gray);
            foreach (Spare space in afford_Layer1)
            {
                g_space.FillRectangle(graybrush, space.startPoint.X + 30, 158, space.len, 112);
            }
            foreach (Spare space in afford_Layer2)
            {
                g_space.FillRectangle(graybrush, space.startPoint.X + 30, 30, space.len, 112);
            }
            //////////////////////////////////////////////////////////////////////////////////////
        }
        private void StuffSystemForm_Load(object sender, EventArgs e)
        {
            if (initCamera())
            {
                StartTimer();
            }
            btn_DisConn.Enabled = false;
        }
        private void StuffSystemForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (timer_cam != null) timer_cam.Enabled = false;
            if (capture != null) capture.Dispose();
            if(t1 != null) t1.Abort();

        }
// ========================================== 영상처리 ==========================================
        private bool initCamera()                       // 카메라 초기설정
        {
            try
            {
                capture = CvCapture.FromCamera(CaptureDevice.DShow, 1);
                capture.SetCaptureProperty(CaptureProperty.FrameWidth, 320);
                capture.SetCaptureProperty(CaptureProperty.FrameHeight, 240);
                return true;
            }
            catch(Exception e)
            {
                MessageBox.Show(e.ToString());
                return false;
            }
        }
        private void StartTimer()                       // 타이머 설정
        {
            timer_cam.Interval = 33;
            timer_cam.Enabled = true;
        }
        public void edgeCatch()                         // edge 검출(현재 안쓰임)
        {
            while (edge)
            {
                img_canny = new IplImage(img.Size, BitDepth.U8, 1);
                Cv.CvtColor(img, img_canny, ColorConversion.BgrToGray);
                Cv.Canny(img_canny, img_canny, 120, 255);

                storage = new CvMemStorage();
                lines = img_canny.HoughLines2(storage, HoughLinesMethod.Standard, 1, Math.PI / 180, 50, 0, 0);
                int limit = Math.Min(lines.Total, 10);
                for (int i = 0; i < limit; i++)
                {
                    CvLineSegmentPolar elem = lines.GetSeqElem<CvLineSegmentPolar>(i).Value;
                    float rho = elem.Rho;
                    float theta = elem.Theta;
                    double a = Math.Cos(theta);
                    double b = Math.Sin(theta);
                    double x0 = a * rho;
                    double y0 = b * rho;
                    CvPoint pt1 = new CvPoint { X = Cv.Round(x0 + 1000 * (-b)), Y = Cv.Round(y0 + 1000 * (a)) };
                    CvPoint pt2 = new CvPoint { X = Cv.Round(x0 - 1000 * (-b)), Y = Cv.Round(y0 - 1000 * (a)) };

                    double alpa = ((pt1.Y - pt2.Y) / (pt1.X - pt2.X + 0.1));

                    CvPoint ptCam1 = new CvPoint { X = (int)(pt1.X - (pt1.Y / (alpa + 0.1))), Y = 0 };
                    CvPoint ptCam2 = new CvPoint { X = (int)(pt2.X - ((pt2.Y - 165) / (alpa + 0.1))), Y = 165 };

                    if ((ptCam1.X >= 100) && (ptCam2.X >= 100) && (ptCam1.X <= 120) && (ptCam2.X <= 120))
                    {
                        timer_cam.Enabled = false;
                        img.Line(ptCam1, ptCam2, CvColor.Red, 2, LineType.AntiAlias, 0);
                        lbl_slope.Text = "Slope : " + alpa.ToString();
                        lbl_pt1.Text = "Point 1 : (" + ptCam1.X.ToString() + ", " + ptCam1.Y.ToString() + ")";
                        lbl_pt2.Text = "Point 2 : (" + ptCam2.X.ToString() + ", " + ptCam2.Y.ToString() + ")";
                        timer_cam.Enabled = true;
                        edge = false;
                        break;
                    }
                }
                imgHough = img.Clone();
                imgHough.Line(new CvPoint { X = 100, Y = 0 }, new CvPoint { X = 100, Y = 165 }, CvColor.Yellow, 1, LineType.AntiAlias, 0);
                imgHough.Line(new CvPoint { X = 120, Y = 0 }, new CvPoint { X = 120, Y = 165 }, CvColor.Yellow, 1, LineType.AntiAlias, 0);
                
                //img_cam.ImageIpl = imgHough;
            }
        }
        private void timer_cam_Tick(object sender, EventArgs e) // 타이머 event
        {
            img = capture.QueryFrame();
            img_canny = new IplImage(img.Size, BitDepth.U8, 1);
            Cv.CvtColor(img, img_canny, ColorConversion.BgrToGray);
            Cv.Canny(img_canny, img_canny, 103, 255);   // private : 120
            //////////////////////////////////////////////////////////////// canny edge 검출
            storage = new CvMemStorage();
            lines = img_canny.HoughLines2(storage, HoughLinesMethod.Standard, 1, Math.PI / 180, 75, 0, 0); // private : 50
            int limit = Math.Min(lines.Total, 10);
            for (int i = 0; i < limit; i++)
            {
                CvLineSegmentPolar elem = lines.GetSeqElem<CvLineSegmentPolar>(i).Value;
                float rho = elem.Rho;
                float theta = elem.Theta;
                double a = Math.Cos(theta);
                double b = Math.Sin(theta);
                double x0 = a * rho;
                double y0 = b * rho;
                CvPoint pt1 = new CvPoint { X = Cv.Round(x0 + 1000 * (-b)), Y = Cv.Round(y0 + 1000 * (a)) };
                CvPoint pt2 = new CvPoint { X = Cv.Round(x0 - 1000 * (-b)), Y = Cv.Round(y0 - 1000 * (a)) };

                double alpa = ((pt1.Y - pt2.Y) / (pt1.X - pt2.X + 0.1));

                CvPoint ptCam1 = new CvPoint { X = (int)(pt1.X - (pt1.Y / (alpa + 0.1))), Y = 0 };
                CvPoint ptCam2 = new CvPoint { X = (int)(pt2.X - ((pt2.Y - 165) / (alpa + 0.1))), Y = 165 };

                alpa = ((ptCam2.Y - ptCam1.Y) / (ptCam2.X - ptCam1.X + 0.1)) * (-1);

                if ((ptCam1.X >= 100) && (ptCam2.X >= 100) && (ptCam1.X <= 120) && (ptCam2.X <= 120))
                {
                   // timer_cam.Enabled = false;
                    img.Line(ptCam1, ptCam2, CvColor.Red, 2, LineType.AntiAlias, 0);
                    lbl_slope.Text = "Slope : " + alpa.ToString();
                    lbl_pt1.Text = "Point 1 : (" + ptCam1.X.ToString() + ", " + ptCam1.Y.ToString() + ")";
                    lbl_pt2.Text = "Point 2 : (" + ptCam2.X.ToString() + ", " + ptCam2.Y.ToString() + ")";

                    if (flag)
                    {
                        checkEdge = true;
                        flag = false;
                    }

                   // timer_cam.Enabled = true;
                    break;
                }
            }
            img.Line(new CvPoint { X = 100, Y = 0 }, new CvPoint { X = 100, Y = 165 }, CvColor.Yellow, 1, LineType.AntiAlias, 0);
            img.Line(new CvPoint { X = 120, Y = 0 }, new CvPoint { X = 120, Y = 165 }, CvColor.Yellow, 1, LineType.AntiAlias, 0);
            imgHough = img.Clone();
            img_cam.ImageIpl = imgHough;
        }
// ========================================== 통신관련 ==========================================
        private void btn_connect_Click(object sender, EventArgs e)
        {
            comport = txt_Com.Text;
            if (comport.Substring(0, 3).CompareTo("COM") != 0)
            {
                MessageBox.Show("올바른 입력값이 아닙니다.");
                return;
            }
            port = new SerialPort(comport, 57600, Parity.None, 8, StopBits.One);
            port.Open();
            txt_System.AppendText("\r\n[SYSTEM] " + txt_Com.Text + "연결 완료");
            //txt_System.Text += "\r\n[System] " + txt_Com.Text + "연결 완료";
            btn_connect.Enabled = false;
            btn_DisConn.Enabled = true;

            Thread thr_Recv = new Thread(new ThreadStart(receivedData));
            thr_Recv.Start();
        }
        private void btn_DisConn_Click(object sender, EventArgs e)
        {
            port.Close();
            btn_connect.Enabled = true;
            btn_DisConn.Enabled = false;
        }
        private void receivedData()
        {
            port.DataReceived += new SerialDataReceivedEventHandler(port_DataReceived);
            //Application.Run();
        }
        private void port_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            if(!modeSet)
            {
                recv=port.ReadExisting();
                //if ((recv.Substring(0,1).CompareTo("5") != 0) && (recv.Substring(0,1).CompareTo("6") != 0) && (recv.Substring(0,1).CompareTo("9") != 0))
                    //MessageBox.Show("잘못된 값 전달 : " + recv.ToString() + "\n올바른 값 전달 : " + test_recv.ToString());
                //else
                //{
                if (((recv.Substring(0,1).CompareTo("5") == 0) && (recv.Substring(1,1).CompareTo("7") != 0)) || (recv.Substring(0,1).CompareTo("6") == 0))
                    modeSet = true;    
                //}
            }
            else
            {
                recv += port.ReadExisting();
            }
                if(recv.Substring(0,1).CompareTo("5")==0)
                {
                    if (recv.Length >= 5)
                    {
                        angle[aCount++] = Int32.Parse(recv.Substring(2, 3));
                        if (aCount == 2)
                            aCount = 0;
                        modeSet = false;
                        mFlag[0] = true;
                    }
                }
                else if(recv.Substring(0,1).CompareTo("6")==0)
                {
                    if (recv.Length >= 3)
                    {
                        txt_System.AppendText("\r\n[SYSTEM] 완료패킷 수신");
                        //txt_System.Text += "\r\n[SYSTEM] 완료패킷 수신";
                        modeSet = false;
                        mFlag[1] = true;
                    }
                }
        }
// ==============================================================================================
        public PutChain putClickInit(Box box, StuffSystemForm ssForm)   // put button 초기설정(chain of responsibility Pattern 적용)
        {
            PutChain measureLength = new MeasureLength(box, ssForm);
            PutChain searchSpace;
            if (cb_Auto.Checked == true)
                searchSpace = new AutoSearchSpace(box, ssForm);
            else
                searchSpace = new SelectedSpace(box, ssForm);
            PutChain putStuff = new PutStuff(box, ssForm);

            measureLength.setNextChain(searchSpace);
            searchSpace.setNextChain(putStuff);

            return measureLength;
        }
        private void btn_Put_Click(object sender, EventArgs e)          // put button click event method
        {
            t1 = new Thread(new ThreadStart(putBtn));
            t1.Start();
        }
        private void putBtn()
        {
            Box box = new Box();
            PutChain chain = putClickInit(box, this);
            chain.execute();
            if (box.index != 0)
                cb_Box.Items.Add("Box " + box.index.ToString());
            this.Invalidate(true);
        }
        private void btn_Pull_Click(object sender, EventArgs e)
        {
            t2 = new Thread(new ThreadStart(pullBtn));
            t2.Start();
        }
        private void pullBtn()
        {
            int num;
            try
            {
                txt_System.AppendText("\r\n[SYSTEM] 반출시작...");
                //txt_System.Text += "\r\n[SYSTEM] 반출시작...";
//                port.Write("0");
 //               port.Write("0");
  //              port.Write("2");        // 반출2시작 보내기

 //               while (!StuffSystemForm.mFlag[1]) { }
 //               mFlag[1] = false;       // 완료 받기

                num = Int32.Parse(cb_Box.SelectedItem.ToString().Substring(4, 1)) - 1;    // box index 추출
                Box box = boxInfo.ElementAt(num);

//                StuffSystemForm.port.Write("2");
//                StuffSystemForm.port.Write("0");
//                if ((box.stuff.length / 100) == 0)
//                    StuffSystemForm.port.Write("0");
//                StuffSystemForm.port.Write(box.stuff.length.ToString());
                // 길이 보내기
//                while (!StuffSystemForm.mFlag[1]) { }
//                StuffSystemForm.mFlag[1] = false;       // 완료 받기

//                StuffSystemForm.port.Write("4");
//                if ((box.stuff.loc.X / 100) == 0)
//                    StuffSystemForm.port.Write("0");
//                StuffSystemForm.port.Write(box.stuff.loc.X.ToString());
//                StuffSystemForm.port.Write(box.stuff.loc.Y.ToString());
                // 위치 보내기

//                while (!StuffSystemForm.mFlag[1]) { }
//                StuffSystemForm.mFlag[1] = false;       // 완료 받기

                if (box.stuff.loc.Y == 1)
                {
                    addSpare(afford_Layer1, box.stuff.loc, box.stuff.length + 30);
                }
                else
                {
                    addSpare(afford_Layer2, box.stuff.loc, box.stuff.length + 30);
                }
                pnl_Shelf.Controls.Remove(box.pb);                      // picturebox 제거
                pnl_Shelf.Controls.Remove(box.lbl);                     // label 제거
                cb_Box.Items.Remove("Box " + box.index.ToString());     // combobox 내용 삭제
                txt_System.AppendText("\r\n[SYSTEM] 반출완료");
                //txt_System.Text += "\r\n반출완료";

                //   boxInfo.Remove(boxInfo.ElementAt(num));                                 // box 제거
            }
            catch
            {
                MessageBox.Show("Box가 설정되지 않았습니다.");
            }
        }
        private void addSpare(List<Spare> afford, Point pt, int len)
        {
            int i;
            for (i = 0; i < afford.Count(); i++)
            {
                if (afford.ElementAt(i).startPoint.X > pt.X)
                {
                    afford.Insert(i, new Spare(pt, len));
                    break;
                }
            }

            if (i != 0)
            {
                if ((afford.ElementAt(i - 1).startPoint.X + afford.ElementAt(i - 1).len + 30) == afford.ElementAt(i).startPoint.X)
                {
                    afford.ElementAt(i - 1).len += (afford.ElementAt(i).len + 30);
                    afford.RemoveAt(i);
                    i--;
                }
            }
                if ((afford.ElementAt(i).startPoint.X + afford.ElementAt(i).len) == afford.ElementAt(i + 1).startPoint.X)
                {
                    afford.ElementAt(i).len += afford.ElementAt(i + 1).len;
                    afford.RemoveAt(i + 1);
                }
                else
                {
                    afford.ElementAt(i).len -= 30;
                }
   
        }
        public static void addBox(StuffSystemForm ssForm, Box box)
        {
            if (ssForm.getPanel().InvokeRequired)
            {
                ssForm.getPanel().BeginInvoke(new Action(() => ssForm.getPanel().Controls.Add(box.lbl)));
                ssForm.getPanel().BeginInvoke(new Action(() => ssForm.getPanel().Controls.Add(box.pb)));
            }
            else
            {
                ssForm.getPanel().Controls.Add(box.lbl);
                ssForm.getPanel().Controls.Add(box.pb);
            }
        }
        public static void addText(StuffSystemForm ssForm, String text)
        {
            if (ssForm.getTextBox().InvokeRequired)
            {
                ssForm.getTextBox().BeginInvoke(new Action(() => ssForm.getTextBox().AppendText("\r\n" + text)));
            }
            else
            {
                ssForm.getTextBox().AppendText("\r\n" + text);
                //ssForm.getTextBox().Text += ("\r\n" + text);
            }
        }
    }
// ======================================= 물건, 여유공간 =======================================
    public class Stuff                                  // 적재 물건
    {
        public Point loc;      // 적재시 물건 좌측 하단 좌표
        public int length;     // 물건 가로길이
        public String memo;    // 사용자가 원하는 내용 저장
    }
    public class Spare                                  // 여유공간
    {
        public Point startPoint;    // 여유공간 시작지점
        public int len;             // 여유공간 길이

        public Spare(Point sPoint, int len)
        {
            this.startPoint = sPoint;
            this.len = len;
        }
    }
    public class Box                                    // GUI Box
    {
        public static int count=0;
        public int index;
        public Stuff stuff;
        public PictureBox pb;
        public Label lbl;
        public Box()
        {
            this.index = 0;
            stuff = new Stuff();
            pb = new PictureBox();
            lbl = new Label();
            count++;
        }
        public Box(int index, Stuff stuff, PictureBox pb, Label lbl)
        {
            this.index = index;
            this.stuff = stuff;
            this.pb = pb;
            this.lbl = lbl;
            count++;
        }
    }
// ==================================== 물건 적재관련 메소드 ====================================
    public abstract class PutChain                      // chain pattern root class
    {
        protected PutChain pChain;
        public Box box;
        public StuffSystemForm ssForm;
        public void setNextChain(PutChain pChain)
        {
            this.pChain = pChain;
        }
        public abstract void execute();
    }
    public class MeasureLength : PutChain               // 전체길이 측정
    {
        public const int LEN = 360;
        public MeasureLength(Box box, StuffSystemForm ssForm)
        { 
            this.box = box;
            this.ssForm = ssForm;
        }
        public override void execute() 
        {
            StuffSystemForm.addText(ssForm, "[SYSTEM] 측정시작...");       
            StuffSystemForm.port.Write("0");
            StuffSystemForm.port.Write("0");
            StuffSystemForm.port.Write("1");        // 측정시작 보내기

            while (!StuffSystemForm.mFlag[1]) { }
            StuffSystemForm.mFlag[1] = false;       // 완료 받기

            //////////////////////////////////////////////////////////////////////////////////////////////////
            StuffSystemForm.flag = true;
            while (!StuffSystemForm.checkEdge) { }
            StuffSystemForm.addText(ssForm, "[SYSTEM] Edge 검출");
            StuffSystemForm.port.Write("1");
            StuffSystemForm.port.Write("1");
            StuffSystemForm.port.Write("1");
            StuffSystemForm.checkEdge = false;
            ///////////////////////////////////////////////////////////////////////////////////////////////////엣지 추출 후 값 전달

            while (!StuffSystemForm.mFlag[0]) { }
            StuffSystemForm.mFlag[0] = false;
            StuffSystemForm.addText(ssForm, "[SYSTEM] 첫번째 각도 검출 : " + StuffSystemForm.angle[0].ToString());
                                                    // 첫번째 각도 받기

            Thread.Sleep(100);
            StuffSystemForm.flag = true;
            while (!StuffSystemForm.checkEdge) { }
            StuffSystemForm.addText(ssForm, "[SYSTEM] Edge 검출");
            StuffSystemForm.port.Write("1");
            StuffSystemForm.port.Write("2");
            StuffSystemForm.port.Write("1");
            StuffSystemForm.checkEdge = false;

            while (!StuffSystemForm.mFlag[0]) { }
            StuffSystemForm.mFlag[0] = false;
            StuffSystemForm.addText(ssForm, "[SYSTEM] 두번째 각도 검출 : " + StuffSystemForm.angle[1].ToString());
                                                    // 두번째 각도 받기
            // 길이 계산
            double a = Math.Tan(StuffSystemForm.angle[0]*Math.PI/180) * LEN;
            double b = Math.Tan(StuffSystemForm.angle[1]*Math.PI/180) * LEN;
            int total = (int)(a+b);
            box.stuff.length = total;
            StuffSystemForm.addText(ssForm, "[SYSTEM] 전체 길이 : " + total.ToString());

            StuffSystemForm.port.Write("2");
            StuffSystemForm.port.Write("0");
            if ((total / 100) == 0)
                StuffSystemForm.port.Write("0");
            StuffSystemForm.port.Write(total.ToString());
                                                    // 길이 보내기
            while (!StuffSystemForm.mFlag[1]) { }
            StuffSystemForm.mFlag[1] = false;       // 완료 받기

            pChain.execute();
        }
    }
    public abstract class SearchSpace : PutChain        // 적정공간 확보
    {
        public override void execute() { }
        public bool searchLayer(int layer)      // 층별 검색
        {
            bool success = false;
            int index=777;
            int minLayer=0;
            int extra=540;
            if (layer == 1)
            {
                for (int i = 0; i < StuffSystemForm.afford_Layer1.Count(); i++)
                {
                    if (StuffSystemForm.afford_Layer1.ElementAt(i).len >= (box.stuff.length + 30))
                    {
                        if ((StuffSystemForm.afford_Layer1.ElementAt(i).len - (box.stuff.length + 30)) < extra)
                        {
                            extra = StuffSystemForm.afford_Layer1.ElementAt(i).len - (box.stuff.length + 30);
                            index = i;
                        }
                    }
                }
                if (index != 777)
                {
                    box.stuff.loc = StuffSystemForm.afford_Layer1.ElementAt(index).startPoint;
                    StuffSystemForm.afford_Layer1.ElementAt(index).startPoint.X += (box.stuff.length + 30);
                    StuffSystemForm.afford_Layer1.ElementAt(index).len -= (box.stuff.length + 30);
                    success = true;
                }
            }
            else if (layer == 2)
            {
                for (int i = 0; i < StuffSystemForm.afford_Layer2.Count(); i++)
                {
                    if (StuffSystemForm.afford_Layer2.ElementAt(i).len >= (box.stuff.length + 30))
                    {
                        if ((StuffSystemForm.afford_Layer2.ElementAt(i).len - (box.stuff.length + 30)) < extra)
                        {
                            extra = StuffSystemForm.afford_Layer2.ElementAt(i).len - (box.stuff.length + 30);
                            index = i;
                        }
                    }
                }
                if (index != 777)
                {
                    box.stuff.loc = StuffSystemForm.afford_Layer2.ElementAt(index).startPoint;
                    StuffSystemForm.afford_Layer2.ElementAt(index).startPoint.X += (box.stuff.length + 30);
                    StuffSystemForm.afford_Layer2.ElementAt(index).len -= (box.stuff.length + 30);
                    success = true;
                }
            }
            else if (layer == 3)    // auto mode
            {
                for (int i = 0; i < StuffSystemForm.afford_Layer1.Count(); i++)
                {
                    if (StuffSystemForm.afford_Layer1.ElementAt(i).len >= (box.stuff.length + 30))
                    {
                        if ((StuffSystemForm.afford_Layer1.ElementAt(i).len - (box.stuff.length + 30)) < extra)
                        {
                            extra = StuffSystemForm.afford_Layer1.ElementAt(i).len - (box.stuff.length + 30);
                            index = i;
                            minLayer = 1;
                        }
                    }
                }
                for (int i = 0; i < StuffSystemForm.afford_Layer2.Count(); i++)
                {
                    if (StuffSystemForm.afford_Layer2.ElementAt(i).len >= (box.stuff.length + 30))
                    {
                        if ((StuffSystemForm.afford_Layer2.ElementAt(i).len - (box.stuff.length + 30)) < extra)
                        {
                            extra = StuffSystemForm.afford_Layer2.ElementAt(i).len - (box.stuff.length + 30);
                            index = i;
                            minLayer = 2;
                        }
                    }
                }
                if (index != 777)
                {
                    if (minLayer == 1)
                    {
                        box.stuff.loc = StuffSystemForm.afford_Layer1.ElementAt(index).startPoint;
                        StuffSystemForm.afford_Layer1.ElementAt(index).startPoint.X += (box.stuff.length + 30);
                        StuffSystemForm.afford_Layer1.ElementAt(index).len -= (box.stuff.length + 30);
                        success = true;
                    }
                    else if(minLayer == 2)
                    {
                        box.stuff.loc = StuffSystemForm.afford_Layer2.ElementAt(index).startPoint;
                        StuffSystemForm.afford_Layer2.ElementAt(index).startPoint.X += (box.stuff.length + 30);
                        StuffSystemForm.afford_Layer2.ElementAt(index).len -= (box.stuff.length + 30);
                        success = true;
                    }
                }
            }
            /*if (layer == 1)
            {
                foreach (Spare spare in StuffSystemForm.afford_Layer1)
                {
                    if (spare.len >= (box.stuff.length + 30))
                    {
                        box.stuff.loc = spare.startPoint;
                        spare.startPoint.X += (box.stuff.length + 30);
                        spare.len -= (box.stuff.length + 30);
                        success = true;
                        break;
                    }
                }
            }
            else if(layer == 2)
            {
                foreach (Spare spare in StuffSystemForm.afford_Layer2)
                {
                    if (spare.len >= (box.stuff.length + 30))
                    {
                        box.stuff.loc = spare.startPoint;
                        spare.startPoint.X += (box.stuff.length + 30);
                        spare.len -= (box.stuff.length + 30);
                        success = true;
                        break;
                    }
                }
            }*/
            return success;
        }
        public void searchSuccess()             // 적정공간 있을시 적용 메소드
        {
            pChain.execute();
        }
    }
    public class AutoSearchSpace : SearchSpace          // 자동모드
    {
        public AutoSearchSpace(Box box, StuffSystemForm ssForm) 
        {
            this.box = box;
            this.ssForm = ssForm;
        }
        public override void execute() 
        {
            StuffSystemForm.addText(ssForm, "[SYSTEM] 자동 탐색중...");
            box.stuff.loc = new Point(30, 1);
            if (!(searchLayer(3)))
                StuffSystemForm.addText(ssForm, "[SYSTEM] 더이상 넣을 공간이 없습니다.");
            else
                searchSuccess();
        }
    }
    public class SelectedSpace : SearchSpace            // 수동모드
    {
        public SelectedSpace(Box box, StuffSystemForm ssForm) 
        { 
            this.box = box;
            this.ssForm = ssForm;
        }
        public override void execute()
        {
            StuffSystemForm.addText(ssForm, "[SYSTEM] 원하는 위치 탐색중...");
            SelectedLayerForm slF = new SelectedLayerForm(box.stuff);
            slF.ShowDialog();
            if (!(searchLayer(box.stuff.loc.Y)))
                StuffSystemForm.addText(ssForm, "[SYSTEM] 더 이상 넣을 공간이 없습니다.");
            else
                searchSuccess();
        }
    }
    public class PutStuff : PutChain                    // 물건 적재
    {
        public PutStuff(Box box, StuffSystemForm ssForm)
        {
            this.box = box;
            this.ssForm = ssForm;
        }
        public override void execute()
        {
            StuffSystemForm.port.Write("3");
            if ((box.stuff.loc.X / 100) == 0)
                StuffSystemForm.port.Write("0");
            StuffSystemForm.port.Write(box.stuff.loc.X.ToString());
            //StuffSystemForm.port.Write("3");
            //StuffSystemForm.port.Write("0");
            //StuffSystemForm.port.Write("0");
            StuffSystemForm.port.Write(box.stuff.loc.Y.ToString());
            // 위치 보내기
            StuffSystemForm.addText(ssForm, "[SYSTEM] Point 좌표 (" + box.stuff.loc.X + ", " + box.stuff.loc.Y + ") 로 전송중");
            /*
            Thread.Sleep(10000);
            
            while (!StuffSystemForm.mFlag[1]) { }
            StuffSystemForm.mFlag[1] = false;       // 완료 받기

            MessageBox.Show("끝났다~~");
            */
            box.pb.SetBounds(box.stuff.loc.X + 30, (box.stuff.loc.Y == 1) ? 190 : 62, box.stuff.length, 80);
            box.pb.BackColor = Color.Brown;
            //ssForm.getPanel().Controls.Add(box.pb);
            box.pb.Name = (StuffSystemForm.boxInfo.Count() + 1).ToString();
            box.pb.Click += new System.EventHandler(this.pb_Click);

            box.lbl.Text = "box " + (StuffSystemForm.boxInfo.Count()+1).ToString();
            box.lbl.SetBounds(box.stuff.loc.X + 30, (box.stuff.loc.Y == 1) ? 175 : 47, 40, 10);
            box.lbl.BackColor = Color.White;
            //ssForm.getPanel().Controls.Add(box.lbl);

            //box.index = StuffSystemForm.boxInfo.Count() + 1;
            box.index = Box.count;
            StuffSystemForm.boxInfo.Add(box);

            StuffSystemForm.addBox(ssForm, box);
            StuffSystemForm.addText(ssForm, "[SYSTEM] 적재 완료");
        }
        private void pb_Click(object sender, EventArgs e)               // picturebox click event method
        {
            int index = Int32.Parse(((PictureBox)sender).Name);
            Box box = StuffSystemForm.boxInfo.ElementAt(index-1);
            MessageBox.Show("====== Box " + box.index.ToString() + " ======\n\nLength : " + box.stuff.length + "\nLayer : " + box.stuff.loc.Y.ToString() + "\nX-coordinate : " + box.stuff.loc.X.ToString());
        }
    }
}
