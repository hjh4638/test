﻿namespace StuffSystem
{
    partial class StuffSystemForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.gb_Shelf = new System.Windows.Forms.GroupBox();
            this.pnl_Shelf = new System.Windows.Forms.Panel();
            this.gb_CamImage = new System.Windows.Forms.GroupBox();
            this.lbl_pt2 = new System.Windows.Forms.Label();
            this.lbl_pt1 = new System.Windows.Forms.Label();
            this.lbl_slope = new System.Windows.Forms.Label();
            this.img_cam = new OpenCvSharp.UserInterface.PictureBoxIpl();
            this.cb_Auto = new System.Windows.Forms.CheckBox();
            this.btn_Put = new System.Windows.Forms.Button();
            this.btn_Pull = new System.Windows.Forms.Button();
            this.cb_Box = new System.Windows.Forms.ComboBox();
            this.timer_cam = new System.Windows.Forms.Timer(this.components);
            this.gb_Comm = new System.Windows.Forms.GroupBox();
            this.btn_DisConn = new System.Windows.Forms.Button();
            this.btn_connect = new System.Windows.Forms.Button();
            this.txt_Com = new System.Windows.Forms.TextBox();
            this.txt_System = new System.Windows.Forms.TextBox();
            this.gb_Stuff = new System.Windows.Forms.GroupBox();
            this.gb_Shelf.SuspendLayout();
            this.gb_CamImage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.img_cam)).BeginInit();
            this.gb_Comm.SuspendLayout();
            this.gb_Stuff.SuspendLayout();
            this.SuspendLayout();
            // 
            // gb_Shelf
            // 
            this.gb_Shelf.Controls.Add(this.pnl_Shelf);
            this.gb_Shelf.Location = new System.Drawing.Point(12, 12);
            this.gb_Shelf.Name = "gb_Shelf";
            this.gb_Shelf.Size = new System.Drawing.Size(614, 334);
            this.gb_Shelf.TabIndex = 0;
            this.gb_Shelf.TabStop = false;
            this.gb_Shelf.Text = "Shelf";
            // 
            // pnl_Shelf
            // 
            this.pnl_Shelf.Location = new System.Drawing.Point(6, 20);
            this.pnl_Shelf.Name = "pnl_Shelf";
            this.pnl_Shelf.Size = new System.Drawing.Size(600, 300);
            this.pnl_Shelf.TabIndex = 6;
            this.pnl_Shelf.Paint += new System.Windows.Forms.PaintEventHandler(this.pnl_Shelf_Paint);
            // 
            // gb_CamImage
            // 
            this.gb_CamImage.Controls.Add(this.lbl_pt2);
            this.gb_CamImage.Controls.Add(this.lbl_pt1);
            this.gb_CamImage.Controls.Add(this.lbl_slope);
            this.gb_CamImage.Controls.Add(this.img_cam);
            this.gb_CamImage.Location = new System.Drawing.Point(632, 12);
            this.gb_CamImage.Name = "gb_CamImage";
            this.gb_CamImage.Size = new System.Drawing.Size(235, 269);
            this.gb_CamImage.TabIndex = 1;
            this.gb_CamImage.TabStop = false;
            this.gb_CamImage.Text = "Cam Image";
            // 
            // lbl_pt2
            // 
            this.lbl_pt2.AutoSize = true;
            this.lbl_pt2.Location = new System.Drawing.Point(9, 245);
            this.lbl_pt2.Name = "lbl_pt2";
            this.lbl_pt2.Size = new System.Drawing.Size(55, 12);
            this.lbl_pt2.TabIndex = 3;
            this.lbl_pt2.Text = "Point 2 : ";
            // 
            // lbl_pt1
            // 
            this.lbl_pt1.AutoSize = true;
            this.lbl_pt1.Location = new System.Drawing.Point(9, 219);
            this.lbl_pt1.Name = "lbl_pt1";
            this.lbl_pt1.Size = new System.Drawing.Size(55, 12);
            this.lbl_pt1.TabIndex = 2;
            this.lbl_pt1.Text = "Point 1 : ";
            // 
            // lbl_slope
            // 
            this.lbl_slope.AutoSize = true;
            this.lbl_slope.Location = new System.Drawing.Point(7, 193);
            this.lbl_slope.Name = "lbl_slope";
            this.lbl_slope.Size = new System.Drawing.Size(49, 12);
            this.lbl_slope.TabIndex = 1;
            this.lbl_slope.Text = "Slope : ";
            // 
            // img_cam
            // 
            this.img_cam.Location = new System.Drawing.Point(7, 21);
            this.img_cam.Name = "img_cam";
            this.img_cam.Size = new System.Drawing.Size(220, 165);
            this.img_cam.TabIndex = 0;
            this.img_cam.TabStop = false;
            // 
            // cb_Auto
            // 
            this.cb_Auto.AutoSize = true;
            this.cb_Auto.Location = new System.Drawing.Point(37, 24);
            this.cb_Auto.Name = "cb_Auto";
            this.cb_Auto.Size = new System.Drawing.Size(84, 16);
            this.cb_Auto.TabIndex = 2;
            this.cb_Auto.Text = "auto mode";
            this.cb_Auto.UseVisualStyleBackColor = true;
            // 
            // btn_Put
            // 
            this.btn_Put.Location = new System.Drawing.Point(132, 20);
            this.btn_Put.Name = "btn_Put";
            this.btn_Put.Size = new System.Drawing.Size(91, 23);
            this.btn_Put.TabIndex = 3;
            this.btn_Put.Text = "Put";
            this.btn_Put.UseVisualStyleBackColor = true;
            this.btn_Put.Click += new System.EventHandler(this.btn_Put_Click);
            // 
            // btn_Pull
            // 
            this.btn_Pull.Location = new System.Drawing.Point(132, 50);
            this.btn_Pull.Name = "btn_Pull";
            this.btn_Pull.Size = new System.Drawing.Size(91, 23);
            this.btn_Pull.TabIndex = 4;
            this.btn_Pull.Text = "Pull";
            this.btn_Pull.UseVisualStyleBackColor = true;
            this.btn_Pull.Click += new System.EventHandler(this.btn_Pull_Click);
            // 
            // cb_Box
            // 
            this.cb_Box.FormattingEnabled = true;
            this.cb_Box.Location = new System.Drawing.Point(6, 52);
            this.cb_Box.Name = "cb_Box";
            this.cb_Box.Size = new System.Drawing.Size(115, 20);
            this.cb_Box.TabIndex = 5;
            // 
            // timer_cam
            // 
            this.timer_cam.Interval = 30;
            this.timer_cam.Tick += new System.EventHandler(this.timer_cam_Tick);
            // 
            // gb_Comm
            // 
            this.gb_Comm.Controls.Add(this.btn_DisConn);
            this.gb_Comm.Controls.Add(this.btn_connect);
            this.gb_Comm.Controls.Add(this.txt_Com);
            this.gb_Comm.Location = new System.Drawing.Point(632, 287);
            this.gb_Comm.Name = "gb_Comm";
            this.gb_Comm.Size = new System.Drawing.Size(231, 82);
            this.gb_Comm.TabIndex = 6;
            this.gb_Comm.TabStop = false;
            this.gb_Comm.Text = "Serial Comm";
            // 
            // btn_DisConn
            // 
            this.btn_DisConn.Location = new System.Drawing.Point(131, 49);
            this.btn_DisConn.Name = "btn_DisConn";
            this.btn_DisConn.Size = new System.Drawing.Size(91, 23);
            this.btn_DisConn.TabIndex = 2;
            this.btn_DisConn.Text = "Disconnect";
            this.btn_DisConn.UseVisualStyleBackColor = true;
            this.btn_DisConn.Click += new System.EventHandler(this.btn_DisConn_Click);
            // 
            // btn_connect
            // 
            this.btn_connect.Location = new System.Drawing.Point(131, 20);
            this.btn_connect.Name = "btn_connect";
            this.btn_connect.Size = new System.Drawing.Size(91, 23);
            this.btn_connect.TabIndex = 1;
            this.btn_connect.Text = "Connect";
            this.btn_connect.UseVisualStyleBackColor = true;
            this.btn_connect.Click += new System.EventHandler(this.btn_connect_Click);
            // 
            // txt_Com
            // 
            this.txt_Com.Location = new System.Drawing.Point(4, 22);
            this.txt_Com.Name = "txt_Com";
            this.txt_Com.Size = new System.Drawing.Size(117, 21);
            this.txt_Com.TabIndex = 0;
            this.txt_Com.Text = "COM2";
            // 
            // txt_System
            // 
            this.txt_System.ImeMode = System.Windows.Forms.ImeMode.On;
            this.txt_System.Location = new System.Drawing.Point(13, 353);
            this.txt_System.Multiline = true;
            this.txt_System.Name = "txt_System";
            this.txt_System.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txt_System.Size = new System.Drawing.Size(613, 110);
            this.txt_System.TabIndex = 7;
            this.txt_System.Text = "============================== Welcome to D-3S!!! ==============================";
            // 
            // gb_Stuff
            // 
            this.gb_Stuff.Controls.Add(this.btn_Pull);
            this.gb_Stuff.Controls.Add(this.cb_Box);
            this.gb_Stuff.Controls.Add(this.btn_Put);
            this.gb_Stuff.Controls.Add(this.cb_Auto);
            this.gb_Stuff.Location = new System.Drawing.Point(632, 375);
            this.gb_Stuff.Name = "gb_Stuff";
            this.gb_Stuff.Size = new System.Drawing.Size(231, 88);
            this.gb_Stuff.TabIndex = 8;
            this.gb_Stuff.TabStop = false;
            this.gb_Stuff.Text = "Stuff";
            // 
            // StuffSystemForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(874, 475);
            this.Controls.Add(this.gb_Stuff);
            this.Controls.Add(this.txt_System);
            this.Controls.Add(this.gb_Comm);
            this.Controls.Add(this.gb_CamImage);
            this.Controls.Add(this.gb_Shelf);
            this.Name = "StuffSystemForm";
            this.Text = "Dynamic Stuff Storage System";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.StuffSystemForm_FormClosing);
            this.Load += new System.EventHandler(this.StuffSystemForm_Load);
            this.gb_Shelf.ResumeLayout(false);
            this.gb_CamImage.ResumeLayout(false);
            this.gb_CamImage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.img_cam)).EndInit();
            this.gb_Comm.ResumeLayout(false);
            this.gb_Comm.PerformLayout();
            this.gb_Stuff.ResumeLayout(false);
            this.gb_Stuff.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gb_Shelf;
        private System.Windows.Forms.GroupBox gb_CamImage;
        private System.Windows.Forms.CheckBox cb_Auto;
        private System.Windows.Forms.Button btn_Put;
        private System.Windows.Forms.Button btn_Pull;
        private System.Windows.Forms.ComboBox cb_Box;
        private System.Windows.Forms.Panel pnl_Shelf;

        public System.Windows.Forms.Panel getPanel()
        {
            return pnl_Shelf;
        }
        public System.Windows.Forms.TextBox getTextBox()
        {
            return txt_System;
        }

        private OpenCvSharp.UserInterface.PictureBoxIpl img_cam;
        private System.Windows.Forms.Timer timer_cam;
        private System.Windows.Forms.Label lbl_slope;
        private System.Windows.Forms.GroupBox gb_Comm;
        private System.Windows.Forms.Button btn_connect;
        private System.Windows.Forms.TextBox txt_Com;
        private System.Windows.Forms.TextBox txt_System;
        private System.Windows.Forms.Button btn_DisConn;
        private System.Windows.Forms.GroupBox gb_Stuff;
        private System.Windows.Forms.Label lbl_pt2;
        private System.Windows.Forms.Label lbl_pt1;
    }
}

