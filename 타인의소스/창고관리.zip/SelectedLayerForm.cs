﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace StuffSystem
{
    public partial class SelectedLayerForm : Form
    {
        StuffSystemForm ssForm;
        Stuff stuff;

        public SelectedLayerForm()
        {
            InitializeComponent();
        }

        public SelectedLayerForm(Stuff stuff)
        {
            InitializeComponent();
            this.stuff = stuff;
        }

        private void btn_Ok_Click(object sender, EventArgs e)
        {
            stuff.loc.Y = (cb_Layer.SelectedItem.ToString().CompareTo("1 Layer")==0) ? 1 : 2;
            this.Close();
        }
    }
}
