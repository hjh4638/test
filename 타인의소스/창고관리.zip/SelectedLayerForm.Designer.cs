﻿namespace StuffSystem
{
    partial class SelectedLayerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Layer = new System.Windows.Forms.Label();
            this.cb_Layer = new System.Windows.Forms.ComboBox();
            this.btn_Ok = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_Layer
            // 
            this.lbl_Layer.AutoSize = true;
            this.lbl_Layer.Location = new System.Drawing.Point(27, 31);
            this.lbl_Layer.Name = "lbl_Layer";
            this.lbl_Layer.Size = new System.Drawing.Size(37, 12);
            this.lbl_Layer.TabIndex = 0;
            this.lbl_Layer.Text = "Layer";
            // 
            // cb_Layer
            // 
            this.cb_Layer.FormattingEnabled = true;
            this.cb_Layer.Items.AddRange(new object[] {
            "1 Layer",
            "2 Layer"});
            this.cb_Layer.Location = new System.Drawing.Point(86, 28);
            this.cb_Layer.Name = "cb_Layer";
            this.cb_Layer.Size = new System.Drawing.Size(157, 20);
            this.cb_Layer.TabIndex = 4;
            // 
            // btn_Ok
            // 
            this.btn_Ok.Location = new System.Drawing.Point(249, 26);
            this.btn_Ok.Name = "btn_Ok";
            this.btn_Ok.Size = new System.Drawing.Size(75, 23);
            this.btn_Ok.TabIndex = 5;
            this.btn_Ok.Text = "Ok";
            this.btn_Ok.UseVisualStyleBackColor = true;
            this.btn_Ok.Click += new System.EventHandler(this.btn_Ok_Click);
            // 
            // SelectedLayerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(336, 59);
            this.Controls.Add(this.btn_Ok);
            this.Controls.Add(this.cb_Layer);
            this.Controls.Add(this.lbl_Layer);
            this.Name = "SelectedLayerForm";
            this.Text = "SelectedLayerForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Layer;
        private System.Windows.Forms.ComboBox cb_Layer;
        private System.Windows.Forms.Button btn_Ok;
    }
}