package com.vsquare.boothapp.page;

import lia.component.PageLayout.Page;
import android.view.View;

public class ShowPage extends Page {
	public void onInit(View v) {
		// TODO Auto-generated method stub
		//this.text = (TextView)v.findViewById(R.id.main_text1);
		//this.text.setOnClickListener(this);
	}

	@Override
	public void onBind(Object o) {
		// TODO Auto-generated method stub
	}

	@Override
	public void onUnbind(Object o) {
		// TODO Auto-generated method stub
	}
}
