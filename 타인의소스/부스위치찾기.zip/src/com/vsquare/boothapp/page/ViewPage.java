package com.vsquare.boothapp.page;

import java.util.ArrayList;
import java.util.List;
import com.vsquare.boothapp.K_nn;
import com.vsquare.boothapp.LoadingActivity;
import com.vsquare.boothapp.MainActivity;
import com.vsquare.boothapp.SelectBoxActivity;
import com.vsquare.boothapp.SettingActivity;
import com.vsquare.boothapp.R;
import com.vsquare.boothapp.StartActivity;
import com.vsquare.boothapp.WifiListActivity;
import com.vsquare.boothapp.HelpClass.EasyUsedDB;
import com.vsquare.boothapp.HelpClass.WifiData;

import lia.component.PageLayout.Page;
import lia.db.DBManager;
import lia.db.DBHelper.OnSetListener;
import lia.manager.ActivityManager;
import android.R.color;
import android.R.string;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewConfiguration;
import android.widget.Button;
import android.widget.Toast;

public class ViewPage extends Page {

	public static final String DB_PATH = "/mnt/sdcard/wifi.db";
	public static final String JOURNAL_PATH = "/mnt/sdcard/wifi.db-journal";
	private final int DB_VERSION = 1;
	
	public static ArrayList<String> WIFI_NAME_LIST = new ArrayList<String>(); 
	public static WIFI_MODE NOW_MODE = WIFI_MODE.NONE;
	
	private int ROW_LENGTH;
	private int COL_LENGTH;
	
	private int WIFI_COUNT;
	private int K_COUNT = 7;
	private int STUDY_COUNT = 2;
	
	public static enum WIFI_MODE
	{
		NONE,
		SETTING_COMPLETE,
		FIND_MODE,
		STACK_MODE,
		STACK_STANDBY_MODE;
	}
	
	/* components */
	private DrawView drawView = null;
	private Button measureBtn = null;
	private Button findBtn = null;
	private Button settingBtn = null;
	
	/* matrix variable */
	private int xSelectedIndex;
	private int ySelectedIndex;
	
	private int rowSelectedIndex; 
	private int colSelectedIndex; 
	
	private WifiManager wifimanager;	// WifiManager variable
	private Activity highRankActivity;
	
	private ArrayList<WifiData> wifiDataList = new ArrayList<WifiData>();
	
	/* rss stregth measure variable */
	
	private int rssMeasureTotalCount = 2;
	private int rssMeasureCount = 0;
	private K_nn knn = null;
	
	private ProgressDialog progressDialog;
	
	
	/* drawview animation timer variable */
	private Thread drawViewThread;
	private static int MESSAGE_ICON_MOVE = 99;
	private static int MESSAGE_ICON_STOP = 999;
	
	private Point prePosition = new Point();
	private Point nowPosition = new Point();
	
	private int drawViewAnimationCount = 0;
	
	private ArrayList<WifiData> settingWifiList = new ArrayList<WifiData>(); 
	
	public void onInit(View v) {
		// TODO Auto-generated method stub
		drawView = (DrawView)findViewById(R.id.drawView);	
		measureBtn = (Button)findViewById(R.id.btn_measure);
		findBtn = (Button)findViewById(R.id.btn_find);
		settingBtn = (Button)findViewById(R.id.btn_setting);
		
		highRankActivity = ActivityManager.getActivity();
		
		NOW_MODE = WIFI_MODE.NONE;
		findBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				if(NOW_MODE == WIFI_MODE.NONE) 
				{
					simpleToast("wifi ������ ���ּ���.");
					return;
				}
				
				NOW_MODE = WIFI_MODE.FIND_MODE;
				drawView.initDrawMode(ROW_LENGTH,COL_LENGTH,ViewPage.this);
				createDB();
				setWifiData();

				threadStart();
			}
		});
		measureBtn.setOnClickListener(new OnClickListener() {
		
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				if(NOW_MODE == WIFI_MODE.NONE) 
				{
					simpleToast("wifi ������ ���ּ���.");
					return;
				}
				
				NOW_MODE = WIFI_MODE.STACK_MODE;
				drawView.initDrawMode(ROW_LENGTH,COL_LENGTH,ViewPage.this);
			}
		});
		settingBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(NOW_MODE == WIFI_MODE.STACK_STANDBY_MODE) return;
				
				Intent intent = new Intent(highRankActivity, SettingActivity.class);
				highRankActivity.startActivityForResult(intent, 1002);
			}
		});
	
		wifimanager = (WifiManager) highRankActivity.getSystemService("wifi");

		// if WIFIEnabled
		if (wifimanager.isWifiEnabled() == false)
			wifimanager.setWifiEnabled(true);
		
        
        prePosition.x = -1; prePosition.y = -1;
        nowPosition.x = -1; nowPosition.y = -1;
	}
	private void threadStart()
	{
		if(drawViewThread != null && drawViewThread.isAlive()) //�ݵ�� null�˻縦 �����ؾ� �Ѵ�. �ؾ��� ���� false�� ���� �˻�� ���� �ʴ´�.
			drawViewThread.interrupt(); //Thread�� interrupt �Ѵ�.
		drawViewThread = new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				while(!drawViewThread.interrupted())
				{	
					SystemClock.sleep(1000);
					messagehandler.sendEmptyMessageDelayed(MESSAGE_ICON_MOVE,1);
				}
			}
		});
        drawViewThread.start(); 
	}
	private void threadStop()
	{
		if(drawViewThread!= null && drawViewThread.isAlive())
			drawViewThread.interrupt();
		
		drawViewThread = null;
	}
	private Handler messagehandler = new Handler()
	{
		public void handleMessage(Message msg)
		{
			if(msg.what == MESSAGE_ICON_STOP)
			{
				drawViewAnimationCount = 0;
			}
			if(msg.what == MESSAGE_ICON_MOVE)
			{
				if(prePosition.x == -1 && prePosition.y == -1)
					return;
				
				drawViewAnimationCount++;
				if(drawViewAnimationCount > 3)
					return;
				drawView.setMiddlePosition(prePosition,nowPosition, drawViewAnimationCount);
			}
		};
	};
	
	
	
	public void setLocationWifiName(String wifiName)
	{
		Log.d("test", wifiName);
		String[] name = new String[1];
		name[0] = wifiName;
		
		//settingWifiList
		
		
		for(int i = 0;i<settingWifiList.size();i++)
		{
			if(settingWifiList.get(i).names[0].equals(wifiName))
			{
				settingWifiList.remove(i);
			}
		}
		WifiData wd = new WifiData(xSelectedIndex,ySelectedIndex,name,null);
		settingWifiList.add(wd);
			
		drawView.setSettedWifiList(settingWifiList);
	}
	
	
	public void setStudyIndexData(int k,int studyCount)
	{
		if(k != -1) K_COUNT = k;
		if(studyCount != -1) STUDY_COUNT = studyCount;
	}
	public void setRowColLength(int row,int col,int wifiCount)
	{
		WIFI_COUNT = wifiCount;
		ROW_LENGTH = row;
		COL_LENGTH = col;
		
		drawView.initDrawMode(ROW_LENGTH,COL_LENGTH,ViewPage.this);
	}
	
	public void matrixSelect(int x, int y,Boolean isLongTouch)
	{
		if(isLongTouch)
		{
			xSelectedIndex = x;
			ySelectedIndex = y;
			
			String[] wifiList = new String[WIFI_COUNT];
			for(int i = 0;i<wifiList.length;i++) wifiList[i] = WIFI_NAME_LIST.get(i);
			
			Intent intent = new Intent(highRankActivity,WifiListActivity.class);
			intent.putExtra("wifiList", wifiList);
			highRankActivity.startActivityForResult(intent, 1004);
			
			return ;
		}
		rowSelectedIndex = x;
		colSelectedIndex = y;
		
		int[] point = new int[2];
		point[0] = x;
		point[1] = y;
		
		Intent intent = new Intent(highRankActivity, SelectBoxActivity.class);
		intent.putExtra("matrix", point);
		highRankActivity.startActivityForResult(intent, 1001);
	}
	public void gridViewPass()
	{
		drawView.setNonSelectPoint(rowSelectedIndex, colSelectedIndex);
		this.NOW_MODE = WIFI_MODE.STACK_MODE; 
	}
	public void gridViewSelectOK()
	{
		progressDialog = ProgressDialog.show(highRankActivity,"", "������ �Դϴ�.",true);
		drawView.setSelectPoint(rowSelectedIndex, colSelectedIndex);
		this.NOW_MODE = WIFI_MODE.STACK_STANDBY_MODE; 
	}
	public void createDB()
	{
		OnSetListener dbListener = new OnSetListener() {	
			@Override
			public void onSet(SQLiteDatabase db, int version) {
				// TODO Auto-generated method stub
			}
		};
        DBManager.init(highRankActivity,DB_PATH, DB_VERSION, dbListener); // db init
        EasyUsedDB.createTable("rss" + WIFI_COUNT,WIFI_COUNT);
        DBManager.exec("create table if not exists wifiresult(matching_tb varchar(20), row int , col int , name varchar(20), rss int); ");
        
	}
	
	private BroadcastReceiver mReceiver = new BroadcastReceiver() //wifi info get
	{
		@Override
		public void onReceive(Context context, Intent intent) 
		{
			final String action = intent.getAction();
			if (action.equals(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)) 
			{
				getWIFIScanResult(); // get WIFISCanResult
				wifimanager.startScan(); // for refresh	
			} 
			else if (action.equals(WifiManager.NETWORK_STATE_CHANGED_ACTION)) 
			{
				highRankActivity.sendBroadcast(new Intent("wifi.ON_NETWORK_STATE_CHANGED"));
			}
		}
	};

	private Point rssMatching(List<ScanResult> scanList)
	{
		if(knn == null)
		{
			knn = new K_nn(K_COUNT);
			knn.setSample(wifiDataList);
		}
		
		String[] names = new String[scanList.size()];
		int[] signals = new int[scanList.size()];
		for(int i = 0;i<scanList.size();i++)
		{
			names[i] = scanList.get(i).SSID;
			signals[i] = scanList.get(i).level;
		}
		
		WifiData wd = new WifiData(0, 0, names, signals);
		Point resultPoint = knn.getResultPoint(wd);
		
		return resultPoint;
	}	
	private List<ScanResult> getSelectWifiList(List<ScanResult> scanList)
	{
		List<ScanResult> getScanList = new ArrayList<ScanResult>(); //
		if(NOW_MODE == WIFI_MODE.FIND_MODE)
		{
			if(wifiDataList.size() == 0) return null;
			for(int i = 0;i<wifiDataList.get(0).names.length;i++)
			{
				for(int j = 0;j<scanList.size();j++)
				{
					if(wifiDataList.get(0).names[i].equals(scanList.get(j).SSID))
					{
						getScanList.add(scanList.get(j));
						break;
					}
				}
			}
		}
		if(NOW_MODE == WIFI_MODE.STACK_STANDBY_MODE)
		{
			for(int i = 0;i<this.WIFI_NAME_LIST.size();i++)
			{
				for(int j = 0;j<scanList.size();j++)
				{
					if(WIFI_NAME_LIST.get(i).equals(scanList.get(j).SSID))
					{
						getScanList.add(scanList.get(j));
						break;
					}
				}
				if(getScanList.size() != (i + 1))
				{
					getScanList.add(scanList.get(0));
				}
			}
		}
		return getScanList;
	}
	private void getWIFIScanResult() 
	{	
		if(NOW_MODE == WIFI_MODE.NONE) return;
		
		List<ScanResult> scanList = wifimanager.getScanResults(); // all wifi list 
		List<ScanResult> getScanList = getSelectWifiList(scanList); 
		
		if(getScanList == null) return;
		
		String infoString = "";
		for (ScanResult scanResult : getScanList) {
			Log.d("wifi list",scanResult.SSID + " : " + scanResult.level);
			infoString += scanResult.SSID + " : " + scanResult.level + " ";
		}
		
		drawView.setWifiRssData(getScanList);
		
		if(NOW_MODE == WIFI_MODE.FIND_MODE)
		{
			if(getScanList == null) return;
			Point result = rssMatching(getScanList);
			Log.d("result",result.x + " " + result.y);
			
			for(int i = 0;i<getScanList.size();i++)
			{
				DBManager.exec("insert into wifiresult values('"+ "rss" + WIFI_COUNT + "'," + result.x + ", " + result.y +", '" + getScanList.get(i).SSID + "','" + getScanList.get(i).level + "');" );				
			}
			
			prePosition.x = nowPosition.x;
			prePosition.y = nowPosition.y;
			nowPosition.x = result.x;
			nowPosition.y = result.y;
			if(prePosition.x == -1 && nowPosition.x != -1)
				drawView.setUserPosition(result.x, result.y);
			
			messagehandler.sendEmptyMessageDelayed(MESSAGE_ICON_STOP,1);
			
			return ;
		}
		
		else if(NOW_MODE == WIFI_MODE.STACK_STANDBY_MODE)
		{
			rssMeasureTotalCount = STUDY_COUNT;
			String[] names = new String[WIFI_NAME_LIST.size()];
			int[] signals = new int[WIFI_NAME_LIST.size()];
			
			for(int i = 0;i<WIFI_NAME_LIST.size();i++) 
				names[i] = WIFI_NAME_LIST.get(i);
			
			rssMeasureCount++;
			for(int i = 0 ; i<WIFI_NAME_LIST.size(); i++)
			{
				signals[i] = getScanList.get(i).level;
			}
			
			EasyUsedDB.setInsertTable("rss" + WIFI_NAME_LIST.size() , rowSelectedIndex , colSelectedIndex ,signals , names);
			// insert db
			if(rssMeasureTotalCount <= rssMeasureCount)
			{				
				drawView.setSelectingPoint(rowSelectedIndex, colSelectedIndex);
				rssMeasureCount = 0;
				NOW_MODE = WIFI_MODE.STACK_MODE;
				
				if(drawView.isMatrixFull())
				{
					simpleToast("������ ��� �Ϸ�Ǿ����ϴ�.");
				}
				
				if(progressDialog!= null && progressDialog.isShowing()) progressDialog.dismiss();
			}	
		}
		else if(NOW_MODE == WIFI_MODE.STACK_MODE)
		{
			if(drawView.isMatrixFull())
			{
				simpleToast("������ ��� �Ϸ�Ǿ����ϴ�.");
				NOW_MODE = WIFI_MODE.SETTING_COMPLETE;
			}
		}
	}
	
	private void setWifiData()
	{
		Cursor cursor = EasyUsedDB.getDBInfo("rss" + WIFI_COUNT);
		cursor.moveToFirst();
		
		int columnCount = cursor.getColumnCount();
		int rowCount = cursor.getCount();
		int index =  (columnCount - 2) / 2;
	
		for(int i = 0;i<rowCount;i++)
		{
			String[] names = new String[index];
			int[] signals = new int[index];
			
			for(int j = 0;j<index;j++)
			{
				names[j] = cursor.getString(j * 2 + 2);
				signals[j] = cursor.getInt(j * 2 + 3);
			}
			WifiData wd = new WifiData(cursor.getInt(0), cursor.getInt(1), names, signals);
			wifiDataList.add(wd);
			
			cursor.moveToNext();
		}
	}
	public void onStop()
	{
		if ( highRankActivity != null )
			highRankActivity.unregisterReceiver(mReceiver);
		
		threadStop();
		DBManager.release();
	}
	@Override
	public void onBind(Object o) {
		// TODO Auto-generated method stub
		Log.d("page", "onBind");
		threadStop();
		initWIFIScan();	
	}
	@Override
	public void onUnbind(Object o) {
		// TODO Auto-generated method stub
		Log.d("page", "onUnBind");
		highRankActivity.unregisterReceiver(mReceiver);
		threadStop();
		DBManager.release();
	}
	private void initWIFIScan() {
		final IntentFilter filter = new IntentFilter(
				WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
		filter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
		highRankActivity.registerReceiver(mReceiver, filter);
		wifimanager.startScan();
	}
	private void simpleToast(String content)
	{
		Toast.makeText(highRankActivity, content, Toast.LENGTH_SHORT).show();
	}
}



class DrawView extends View // view �׸��� �͸� ����Ѵ�.
{
	private final int VIEW_WIDTH = 720;
	private final int VIEW_HEIGHT = 900;
	
	private int col;
	private int row;
	
	private Paint paint = new Paint();
	private Bitmap vertexBitmap; 
	private Bitmap userBitmap;
	
	private Bitmap checkedBitmap;
	private Bitmap checkingBitmap;
	private Bitmap nonCheckBitmap; 
	
	private Bitmap[][] gridViewBitmapArray; 
	
	private int baseX;
	private int baseY;
	
	private int height = 0;
	private int width = 0;

	private int errorW;
	private int errorH;
	
	private Point userPoint;
	private boolean[][] matrixCheck;
	private ViewPage parentsClass;
	
	private ArrayList<WifiData> settedWifiNameList;
	private List<ScanResult> settedWifiList;
	
	private Point touchPoint = new Point();
	
	
	public void setWifiRssData(List<ScanResult> wifiList)
	{
		settedWifiList = wifiList;
	}
	public DrawView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init();
		// TODO Auto-generated constructor stub
	}
	public DrawView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
		// TODO Auto-generated constructor stub
	}
	public DrawView(Context context) {
		super(context);
		init();
		// TODO Auto-generated constructor stub
	}
	
	public void init()
	{
		checkedBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.img_wifi);
		checkingBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.img_wifing);
		vertexBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.img_rss);
		userBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.img_mypoint);
		nonCheckBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.img_pass);
		
		userPoint = new Point(0,0);
		
		baseX = 40;
		baseY = 140;
		
		errorW = this.checkedBitmap.getWidth()/2;
		errorH = this.checkedBitmap.getHeight()/2;
	
		
	}
	
	public boolean isMatrixFull()
	{
		for(int j = 0;j<col;j++)
		{
			for(int i = 0;i<row;i++)
			{
				if(matrixCheck[j][i] == false)
				{
					return false;
				}
			}
		}
		return true;
	}
	public void initDrawMode(int row,int col,ViewPage vp)
	{
		Log.d("test",this.getBottom() + " " + this.getLeft() + " " + getRight() + " " + getTop());
		this.setRight(1000);
		this.setBottom(1000);
		this.requestLayout();
		// 900 0 720 0 
		Log.d("test",this.getBottom() + " " + this.getLeft() + " " + getRight() + " " + getTop());
		this.col = col;
		this.row = row;
		this.parentsClass = vp;
		
		if(col * 5 > 200) this.height = col * 5; 
		else this.height = 600;
		
		if(row * 5 > 200) this.width = row * 5; 
		else this.width = 600;
		
		matrixCheck = new boolean[col][row];
		gridViewBitmapArray = new Bitmap[col][row];
		
		for(int j = 0;j<col;j++)
		{
			for(int i = 0;i<row;i++)
			{
				matrixCheck[j][i] = false;
				gridViewBitmapArray[j][i] = null;
			}
		}
		if(settedWifiList!= null)
			settedWifiList.clear();
		this.invalidate();
	}	
	public void setSettedWifiList(ArrayList<WifiData> settedWifiList)
	{
		this.settedWifiNameList = settedWifiList;
		this.invalidate();
	}
	public void setUserPosition(int row,int col)
	{
		if(this.row > row) return;
		if(this.col > col) return;
		
		Point pt = matrixToPoint(row,col);
		userPoint.x = pt.x + (this.width / row)/2 - errorW;
		userPoint.y = pt.y + (this.height / col)/2 - errorH;
		
		this.invalidate();
	}
	public void setMiddlePosition(Point startPoint, Point endPoint, int middleCount)
	{
		int divisionIndex = 3;

		if(startPoint.x > row) return;
		if(startPoint.y > col) return;
		if(endPoint.x > row) return;
		if(endPoint.y > col) return;
		
		Point start = matrixToPoint(startPoint.x,startPoint.y);
		Point end = matrixToPoint(endPoint.x,endPoint.y);
		
		start.x = start.x + (this.width / row)/2 - errorW;
		start.y = start.y + (this.height / col)/2 - errorH;
				
		end.x = end.x + (this.width / row)/2 - errorW;
		end.y = end.y + (this.height / col)/2 - errorH;
		
		userPoint.x = start.x + middleCount * (end.x - start.x)/divisionIndex ; 
		userPoint.y = start.y + middleCount * (end.y - start.y)/divisionIndex ;
		
		invalidate();		
	}
	public void setNonSelectPoint(int x, int y)
	{
		this.gridViewBitmapArray[y][x] = nonCheckBitmap;
		this.matrixCheck[y][x] = true;
		this.invalidate();
	}
	public void setSelectPoint(int x,int y)
	{
		this.gridViewBitmapArray[y][x] = checkingBitmap;
		this.matrixCheck[y][x] = true;
		this.invalidate();
	}
	public void setSelectingPoint(int x, int y)
	{
		this.gridViewBitmapArray[y][x] = checkedBitmap;
		this.matrixCheck[y][x] = true;
		this.invalidate();
	}
	private Point matrixToPoint(int x, int y)
	{
		int cx = x * (this.width / row) + errorW + baseX;
		int cy = y * (this.height / col) + errorH + baseY;
		
		return new Point(cx,cy);
	}
	private Point pointToMatrix(int x, int y)
	{
		if(row == 0 || col == 0)new Point(0,0);
	
		int cx = (x - errorW - baseX) / (this.width / row);
		int cy = (y - errorH - baseY) / (this.height / col);
		return new Point(cx,cy);
	}
	protected void onDraw(Canvas canvas)
	{
		if(!(this.width > 0 && this.height > 0)) return;
		
		paint.setTextSize(35.0f);
		paint.setStrokeWidth(3.0f);
		paint.setColor(Color.BLACK);
		canvas.drawColor(color.white);
	
		if(ViewPage.NOW_MODE == ViewPage.WIFI_MODE.STACK_MODE 
				|| ViewPage.NOW_MODE == ViewPage.WIFI_MODE.STACK_STANDBY_MODE)
		{	
			
			for(int j = 0;j<col;j++)
			{
				for(int i = 0;i<row;i++)
				{
					if(	matrixCheck[j][i])
					{
						Point pt = matrixToPoint(i,j);
						canvas.drawBitmap(gridViewBitmapArray[j][i], pt.x + (this.width / row)/2 - errorW, pt.y + (this.height / col)/2 - errorH, paint);
					}
				
				}
			}
				
		}
		for(int i = 0;i<row + 1;i++)
		{
			canvas.drawLine(baseX + i * this.width / row + errorW, baseY + errorH, baseX + i * this.width / row + errorW, baseY + this.height + errorH, paint);
		}
		for(int i = 0;i<col + 1;i++)
		{
			canvas.drawLine(baseX  + errorW, baseY + i * this.height / col + errorH , baseX + this.width + errorW, baseY +  i * this.height / col + errorH, paint);
		}
		
		if(ViewPage.NOW_MODE == ViewPage.WIFI_MODE.FIND_MODE )
		{
			if(userPoint.x != 0 || userPoint.y !=0) 
			{
				paint.setColor(Color.BLUE);
				canvas.drawBitmap(userBitmap, userPoint.x, userPoint.y, paint);
			}
		}
		
		if(this.settedWifiNameList != null)
		{
			for(int i = 0;i<settedWifiNameList.size();i++)
			{
				Point pt = new Point();
				pt.x = settedWifiNameList.get(i).row - vertexBitmap.getWidth()/2;
				pt.y = settedWifiNameList.get(i).col- vertexBitmap.getHeight()/2;
				
				int rss = 0;
				for(int j = 0;j<settedWifiList.size();j++)
				{
					if(settedWifiList.get(j).SSID.equals(settedWifiNameList.get(i).names[0]))
					{
						rss = settedWifiList.get(j).level;
					}
				}
				canvas.drawBitmap(vertexBitmap, pt.x, pt.y, paint);
				canvas.drawText(settedWifiNameList.get(i).names[0] + " : " + rss, (float)pt.x - 20, (float)pt.y, paint);
			}
		}
	}
	private static final int LONG_PRESS = 2;
    private static final int SHORT_PRESS = 1;
	private Boolean isClick = false;
	private Handler messagehandler = new Handler()
	{
		public void handleMessage(Message msg)
		{
			switch(msg.what){
    		
    		case LONG_PRESS:
    			parentsClass.matrixSelect(touchPoint.x,touchPoint.y,true);
    			isClick = true;
    		
    			break;
    		case SHORT_PRESS:
    			if(ViewPage.NOW_MODE == ViewPage.WIFI_MODE.FIND_MODE) break;
    			if(ViewPage.NOW_MODE == ViewPage.WIFI_MODE.SETTING_COMPLETE) break;
    			
    			Point pt = pointToMatrix(touchPoint.x,touchPoint.y);
    			if(pt.y > col - 1 || pt.x > row - 1) break;
    			
    			parentsClass.matrixSelect(pt.x,pt.y,false);
    			
    			isClick = true;
    			break;
			default:
				 throw new RuntimeException("Unknown message " + msg); //never

			}
		};
	};
	public boolean onTouchEvent(MotionEvent event) 
	{

		if(ViewPage.NOW_MODE == ViewPage.WIFI_MODE.NONE || 
				ViewPage.NOW_MODE == ViewPage.WIFI_MODE.STACK_STANDBY_MODE ) 
		{
			return false;
		}
			
		int x = (int)event.getX();
		int y = (int)event.getY();
        
        switch(event.getAction()) 
        {
        
        case MotionEvent.ACTION_DOWN:
        	
			touchPoint.x = x; touchPoint.y = y;
    		
        	messagehandler.removeMessages(LONG_PRESS);
    		messagehandler.sendEmptyMessageDelayed(LONG_PRESS, 1000);

    		isClick = false;
            break;
        case MotionEvent.ACTION_MOVE:
        	
        	break;
        case MotionEvent.ACTION_UP:
        	if(isClick) return false;
        	messagehandler.removeMessages(LONG_PRESS);
        	messagehandler.sendEmptyMessageDelayed(SHORT_PRESS, 1);
            break;
        case MotionEvent.ACTION_CANCEL:
        	messagehandler.removeMessages(LONG_PRESS);
        	break;
        }
        //this.invalidate();
        return true;
    }
	@Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        this.setMeasuredDimension(VIEW_WIDTH,VIEW_HEIGHT);     
    }
}
