package com.vsquare.boothapp;

import java.util.ArrayList;
import java.util.List;

import com.vsquare.boothapp.page.BoardPage;
import com.vsquare.boothapp.page.CompanyPage;
import com.vsquare.boothapp.page.HomePage;
import com.vsquare.boothapp.page.ShowPage;
import com.vsquare.boothapp.page.ViewPage;

import lia.activity.BaseActivity;
import lia.component.ButtonTab;
import lia.component.PageLayout;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Canvas;
import android.graphics.Point;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.ScrollView;
import android.widget.Toast;


public class MainActivity extends BaseActivity {

	ButtonTab buttonTab;
	PageLayout pageClassLayout;

	private float mx, my;
	private float curX, curY;
	
	private ScrollView vScroll;
	private HorizontalScrollView hScroll;
	
	private ViewPage viewPage = new ViewPage(); 

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		 vScroll = (ScrollView) findViewById(R.id.vScroll);
	     hScroll = (HorizontalScrollView) findViewById(R.id.hScroll);

		this.buttonTab = (ButtonTab)super.findViewById(R.id.tabpage_buttonTab);
        this.pageClassLayout = (PageLayout)super.findViewById(R.id.tabpage_pageLayout);
        
        this.pageClassLayout.addPage( new HomePage() );
        this.pageClassLayout.addPage( new ShowPage() );
        this.pageClassLayout.addPage( new CompanyPage() );
        this.pageClassLayout.addPage( viewPage );
        this.pageClassLayout.addPage( new BoardPage() );
        
        this.buttonTab.setPageLayout(this.pageClassLayout);
        this.buttonTab.setIndex(0);
        
        // wifi�� ���� �� ��
	}
	
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if(requestCode == 1001) // select box
		{
			if (resultCode == Activity.RESULT_OK)
			{
				viewPage.gridViewSelectOK();
			}
			if(resultCode == Activity.RESULT_CANCELED)
			{
				return;
			}
			if(resultCode == Activity.RESULT_FIRST_USER)
			{
				viewPage.gridViewPass();
			}
		}
		else if(requestCode == 1002) // setting activity
		{
			if (resultCode == Activity.RESULT_OK)
			{
				int col = data.getIntExtra("col", 2);
				int row = data.getIntExtra("row", 2);
				int wifiCount = data.getIntExtra("wifi_count", 2); 
					
				int k = data.getIntExtra("k_count", -1);
				int studyCount = data.getIntExtra("study_count", -1);
				
				viewPage.setStudyIndexData(k,studyCount);
				
				viewPage.setRowColLength(row, col, wifiCount);
				viewPage.createDB();
			}
			else if(resultCode == Activity.RESULT_CANCELED)
			{
				return;
			}
			else{}
		}
		else if(requestCode == 1004) // wifi List
		{
			if (resultCode == Activity.RESULT_OK)
			{
				String itemValue = data.getStringExtra("itemValue");
				Log.d("item value",itemValue);
				viewPage.setLocationWifiName(itemValue);
			}
			else if(resultCode == Activity.RESULT_CANCELED)
			{
				return;
			}
			else{}
		}
	}
	
	
	protected void onStop()
	{
		super.onStop();
		
	}
	protected void onRestart()
	{
		super.onRestart();
	}
	protected void onDestroy()
	{
		super.onDestroy();
		viewPage.onStop();
	}
	
	@Override
    public boolean onTouchEvent(MotionEvent event) {
        float curX, curY;

        switch (event.getAction()) {

            case MotionEvent.ACTION_DOWN:
                mx = event.getX();
                my = event.getY();
                break;
            case MotionEvent.ACTION_MOVE:
                curX = event.getX();
                curY = event.getY();
               vScroll.scrollBy((int) (mx - curX), (int) (my - curY));
                hScroll.scrollBy((int) (mx - curX), (int) (my - curY));
                mx = curX;
                my = curY;
                break;
            case MotionEvent.ACTION_UP:
                curX = event.getX();
                curY = event.getY();
               vScroll.scrollBy((int) (mx - curX), (int) (my - curY));
                hScroll.scrollBy((int) (mx - curX), (int) (my - curY));
                break;
        }

        return true;
    }
	
}


