package com.vsquare.boothapp.HelpClass;

public class WifiData {
	public int row;
	public int col;
	public String[] names;
	public int[] signals; 
	
	public WifiData(int row,int col,String[] names,int[] signals)
	{
		this.row = row;
		this.col = col;
		this.names = names;
		this.signals = signals;
	}
}
