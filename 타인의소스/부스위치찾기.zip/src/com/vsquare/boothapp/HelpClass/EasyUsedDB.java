package com.vsquare.boothapp.HelpClass;

import lia.db.DBHelper;
import lia.db.DBManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class EasyUsedDB {
	public static void createTable(String table,int listSize)
	{
		String query = "create table if not exists "+ table +"(_row integer ,_col integer";
		for(int i = 0;i<listSize;i++) query += ", wifi" + i +" text, rss" + i + " integer";
		query += ");";
		
		Log.d("db Log", query);
		DBManager.exec(query);
	}
	public static void allWifiInfoDBInsert(String table,WifiData[][] wifiGridData)
	{
		
		for(int j = 0;j<wifiGridData.length;j++)
		{
			for(int i = 0;i<wifiGridData[j].length;i++)
			{
				int[] rss = wifiGridData[j][i].signals;
				String[] name = wifiGridData[j][i].names;
				EasyUsedDB.setInsertTable(table,i,j,rss,name);
			}
		}
	}
	public static void setInsertTable(String table,int row,int col,int[] rssArray,String[] wifiNameArray)
	{
		String query = "insert into " + table +"(_row, _col";
		for(int i = 0;i<rssArray.length;i++) query += ", wifi" + i +", rss" + i;
		query += ") values(" + row +"," + col;
		for(int i = 0;i<rssArray.length;i++) 
		{
			query += (",'" + wifiNameArray[i] + "'," + rssArray[i]);
		}
		query +=  ");";
		
		Log.d("db Log", query);
		
		DBManager.exec(query);
	}
	public static Cursor getDBInfo(String table)
	{
		String query = "select * from " + table + ";";
		Log.d("db Log", query);
		return DBManager.query(query);
	}
}
