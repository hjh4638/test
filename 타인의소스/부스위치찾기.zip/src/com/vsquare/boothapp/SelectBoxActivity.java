package com.vsquare.boothapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class SelectBoxActivity extends Activity {

	private Button selectButton;
	private Button cancelButton;
	private Button passButton;
	
	private TextView messageTextView;
	
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	
	    setContentView(R.layout.activity_selectbox);
	   //
	    selectButton = (Button)findViewById(R.id.button_select);
	    cancelButton = (Button)findViewById(R.id.button_cancel);
	    passButton = (Button)findViewById(R.id.button_notselect);
	    
	    messageTextView = (TextView)findViewById(R.id.textview_message);
	    this.setFinishOnTouchOutside(false);

	    Intent intent = getIntent();
	    int[] matrix = intent.getIntArrayExtra("matrix"); 
	    
	    messageTextView.setText(" x : " + matrix[0] + " y : " + matrix[1] + " ��ǥ�� �����Ͻðڽ��ϱ�??");
	    selectButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				setResult(Activity.RESULT_OK, new Intent());
	            finish();
			}
		});
	    passButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				setResult(Activity.RESULT_FIRST_USER, new Intent());
	            finish();
			}
		});
	    cancelButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				setResult(Activity.RESULT_CANCELED, new Intent());
	            finish();
			}
		});
	    
	    // TODO Auto-generated method stub
	}

}
