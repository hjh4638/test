package com.vsquare.boothapp;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.ScrollView;

public class MyVerticalScrollView extends ScrollView {

	  public MyVerticalScrollView(Context context, AttributeSet attrs, int defStyle) {
	        super(context, attrs, defStyle);
	    }

	    public MyVerticalScrollView(Context context, AttributeSet attrs) {
	        super(context, attrs);
	    }

	    public MyVerticalScrollView(Context context) {
	        super(context);
	    }

	    @Override
	    public boolean onTouchEvent(MotionEvent ev) {
	        return false;
	    }


}
