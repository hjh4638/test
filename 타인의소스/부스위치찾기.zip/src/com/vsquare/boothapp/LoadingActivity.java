package com.vsquare.boothapp;

import lia.activity.BaseActivity;
import lia.util.TaskUtils;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class LoadingActivity extends BaseActivity{
	
	private final int loadingTime = 500;
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	
	    setContentView(R.layout.activity_loading);

	    
	    TaskUtils.postRunnable(new Runnable() {
			
			@Override
			public void run() {
				
                Intent Intent = new Intent(LoadingActivity.this,StartActivity.class);
                startActivity(Intent);
                finish();
				
			}
		}, loadingTime);
	    
	}

}
