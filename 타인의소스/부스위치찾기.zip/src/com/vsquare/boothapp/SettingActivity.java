package com.vsquare.boothapp;

import java.io.File;
import java.util.ArrayList;

import com.vsquare.boothapp.page.ViewPage;

import lia.activity.BaseActivity;
import lia.db.DBManager;
import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable.Orientation;
import android.os.Bundle;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class SettingActivity extends BaseActivity {

	private LinearLayout wifiListAddLayout;
	private Button wifiCompleteButton;
	private Button wifiCancelButton;
	private TextView wifiListText;
	
	private EditText wifiListEdit;
	private EditText wifiWidthEdit;
	private EditText wifiHeightEdit;
	private EditText wifiCountEdit;
	private EditText KCountEdit;
	private EditText studyCountEdit;
	
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.activity_setting);
	    this.setFinishOnTouchOutside(false);
	    
	    wifiListAddLayout = (LinearLayout)findViewById(R.id.WifiAdd_Layout);
	    wifiListText = (TextView)findViewById(R.id.WifiAdd_Text);
	    wifiCompleteButton = (Button)findViewById(R.id.wifiComplete_Button);
	    wifiCancelButton = (Button)findViewById(R.id.wificancel_Button);
	    
	    wifiListEdit = (EditText)findViewById(R.id.WifiAdd_Edit1);
	    
	    wifiHeightEdit = (EditText)findViewById(R.id.WifiHeight_Edit);
	    wifiWidthEdit = (EditText)findViewById(R.id.WifiWidth_Edit);
	    wifiCountEdit = (EditText)findViewById(R.id.WifiCount_Edit);
	    KCountEdit = (EditText)findViewById(R.id.WifiKCount_Edit);
	    studyCountEdit = (EditText)findViewById(R.id.WifiStudyCount_Edit);
	    
	    wifiCompleteButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(!EditBoxChecked()) return;
						
				File dbFile = new File(ViewPage.DB_PATH);
				if(dbFile.exists())	dbFile.delete();
				
				File journalFile = new File(ViewPage.JOURNAL_PATH);
				if(journalFile.exists()) journalFile.delete();
				
				ViewPage.NOW_MODE = ViewPage.WIFI_MODE.SETTING_COMPLETE;
				setResult(Activity.RESULT_OK, setIntentData());
	            finish();
			}
		});
	    wifiCancelButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				setResult(Activity.RESULT_CANCELED, new Intent());
	            finish();
			}
		});
	}
	private Boolean EditBoxChecked()
	{
		if(wifiHeightEdit.getText().toString().equals("") || wifiWidthEdit.getText().toString().equals("")|| wifiCountEdit.getText().toString().equals("") || wifiListEdit.getText().toString().equals(""))
		{
			Toast.makeText(SettingActivity.this, "��� �Է��� �ּ���.", Toast.LENGTH_LONG).show();
			return false;
		}
		ViewPage.WIFI_NAME_LIST.clear();
		
		for(int i = 0;i<Integer.parseInt(wifiCountEdit.getText().toString());i++)
		{
			ViewPage.WIFI_NAME_LIST.add(wifiListEdit.getText().toString() + (1 + i));
		}
		return true;
	}
	private Intent setIntentData()
	{
		Intent intent = getIntent();
		
		intent.putExtra("col", Integer.parseInt(wifiHeightEdit.getText().toString()));
		intent.putExtra("row", Integer.parseInt(wifiWidthEdit.getText().toString()));
		intent.putExtra("wifi_count", Integer.parseInt(wifiCountEdit.getText().toString()));
		
		if(!KCountEdit.getText().toString().equals("")) intent.putExtra("k_count", Integer.parseInt(KCountEdit.getText().toString()));
		if(!studyCountEdit.getText().toString().equals("")) intent.putExtra("study_count", Integer.parseInt(studyCountEdit.getText().toString()));
				
		return intent;
	}
	 // �Լ��� ����????
	
	public int setDP(int px)
	{
		DisplayMetrics outMetrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(outMetrics);
		
		return px * (int)outMetrics.density;
	}
}
