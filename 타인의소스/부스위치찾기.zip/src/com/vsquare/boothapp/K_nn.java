package com.vsquare.boothapp;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;

import android.graphics.Point;
import android.util.Log;

import com.vsquare.boothapp.HelpClass.WifiData;

public class K_nn {
	
	private int k;
	private float weight = 0.6f;
	private ArrayList<WifiData> dataList;
	private Point previousResultPoint = new Point(-1,-1);
	private float lengthLimit;
	private float nearLength;
	
	public K_nn(int k)
	{
		this.k = k;
	}
	public K_nn()
	{
		this.k = 6;
	}
	public void setSample(ArrayList<WifiData> wifiDataList)
	{
		dataList = wifiDataList;
		lengthLimit = dataList.size() * 6;
	}
	
	
	/*
	 * 
	 * K-nn ã�� �κ����� wifi rss ����Ÿ�� ������ ��ǥ���� return �ȴ�.
	 * 
	 * 
	 * 
	 * */
	public Point getResultPoint(final WifiData sample)
	{
		if(dataList.size() < this.k) return new Point(0,0);
		float[] weakArray = new float[this.k];
		
		Collections.sort(this.dataList,new Comparator<WifiData>() 
				{
			 
			@Override
					public int compare(WifiData arg0, WifiData arg1) 
					{
			        	int temp1 = 0;
			        	int temp2 = 0;
			        	
			        	int index = 0;
						for(int i = 0;i<sample.signals.length;i++)
						{
							if(arg0.names[index].equals(sample.names[i])) temp1 += Math.abs(arg0.signals[index] - sample.signals[i]);
			        		else i--;
			        			
							index++;
						}
						index = 0;
						for(int i = 0;i<sample.signals.length;i++)
						{
							if(arg1.names[index].equals(sample.names[i])) temp2 += Math.abs(arg1.signals[index] - sample.signals[i]);
			        		else i--;
			        			
							index++; 
						}
						
						return temp1 - temp2;
						
					}});
		for(int i = 0;i<dataList.size();i++)
		{
			String temp = "";
			for(int j = 0;j<dataList.get(i).names.length;j++)
			{
				temp += dataList.get(i).names[j] + " : ";
				temp += dataList.get(i).signals[j] + " ";
			}	
		}
		
		//weakArray
		for(int i = 0;i<this.k;i++)
		{
			int length = 0;
			int index = 0;
			for(int j = 0;j<sample.signals.length;j++)
			{
				if(dataList.get(i).names[index].equals(sample.names[j])) length += Math.abs(dataList.get(i).signals[index] - sample.signals[j]);
        		else j--;
        			
				index++; 
			}
			weakArray[i] = weight / (float)length;
			if(i == 0) nearLength = length;
			if(i == 0 && lengthLimit < length)
			{
				return previousResultPoint;
			}
		}
		
		int tempSelectedRow = 0;
		int tempSelectedCol = 0;
		float tempSelectingCount = 0.0f;
		float tempSelectingCountSave = -1.0f;
		
		for(int i = 0;i<this.k;i++)
		{
			Point tempPt = new Point(dataList.get(i).row, dataList.get(i).col);
			for(int j = i ;j<this.k;j++)
			{
				if(dataList.get(j).row == tempPt.x && dataList.get(j).col == tempPt.y)
				{
					tempSelectingCount += weakArray[j];
				}
			}
			if(tempSelectingCount > tempSelectingCountSave)
			{
				tempSelectingCountSave = tempSelectingCount;
				tempSelectedCol = dataList.get(i).col;
				tempSelectedRow = dataList.get(i).row;
			}
			tempSelectingCount = 0.0f;
		}
		
		Point resultPoint = new Point(tempSelectedRow, tempSelectedCol);
		
		if(!isNearPoint(resultPoint, previousResultPoint) && previousResultPoint.x != -1)
		{
			if(!(nearLength < dataList.size() * 2))
				return previousResultPoint;
		}
		previousResultPoint.x = resultPoint.x;
		previousResultPoint.y = resultPoint.y;
		
		return resultPoint;
	}	
	private Boolean isNearPoint(Point pt1,Point pt2)
	{
		if((Math.abs(pt1.x - pt2.x) > 1) || (Math.abs(pt1.y - pt2.y) > 1))
			return false;
		else 
			return true;	
	}
}



