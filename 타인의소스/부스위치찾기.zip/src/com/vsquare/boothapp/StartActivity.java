package com.vsquare.boothapp;

import lia.activity.BaseActivity;
import lia.manager.ActivityManager;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;

public class StartActivity extends BaseActivity {

	private LinearLayout ll_start;
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.activity_start);
		
		ll_start = (LinearLayout)findViewById(R.id.page_start);
		
		ll_start.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {

				ActivityManager.startActivity(MainActivity.class);
			}
		});
	}

}

//
//02-19 15:44:47.513: E/InputEventReceiver(23737): Exception dispatching input event.
//02-19 15:44:47.513: E/MessageQueue-JNI(23737): Exception in MessageQueue callback: handleReceiveCallback
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): java.lang.NullPointerException
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at lia.db.DBManager.release(DBManager.java:52)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at com.vsquare.boothapp.page.ViewPage.onUnbind(ViewPage.java:520)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at lia.component.PageLayout.unBindAt(PageLayout.java:467)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at lia.component.PageLayout.changePage(PageLayout.java:291)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at lia.component.PageLayout.setIndexWithoutTabInPageLayout(PageLayout.java:284)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at lia.component.PageLayout.setIndexWithoutTabInPageLayout(PageLayout.java:249)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at lia.component.PageLayout.setIndexWithoutTab(PageLayout.java:244)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at lia.component.Tab.setIndex(Tab.java:76)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at lia.component.ButtonTab.setIndex(ButtonTab.java:66)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at lia.component.ButtonTab$1.onClick(ButtonTab.java:30)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at lia.component.ImageButton.onTouchEvent(ImageButton.java:198)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.View.dispatchTouchEvent(View.java:7831)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.ViewGroup.dispatchTransformedTouchEvent(ViewGroup.java:2441)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.ViewGroup.dispatchTouchEvent(ViewGroup.java:2174)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.ViewGroup.dispatchTransformedTouchEvent(ViewGroup.java:2441)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.ViewGroup.dispatchTouchEvent(ViewGroup.java:2174)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.ViewGroup.dispatchTransformedTouchEvent(ViewGroup.java:2441)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.ViewGroup.dispatchTouchEvent(ViewGroup.java:2174)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.ViewGroup.dispatchTransformedTouchEvent(ViewGroup.java:2441)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.ViewGroup.dispatchTouchEvent(ViewGroup.java:2174)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.ViewGroup.dispatchTransformedTouchEvent(ViewGroup.java:2441)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.ViewGroup.dispatchTouchEvent(ViewGroup.java:2174)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at com.android.internal.policy.impl.PhoneWindow$DecorView.superDispatchTouchEvent(PhoneWindow.java:2326)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at com.android.internal.policy.impl.PhoneWindow.superDispatchTouchEvent(PhoneWindow.java:1612)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.app.Activity.dispatchTouchEvent(Activity.java:2494)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at com.android.internal.policy.impl.PhoneWindow$DecorView.dispatchTouchEvent(PhoneWindow.java:2274)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.View.dispatchPointerEvent(View.java:8039)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.ViewRootImpl$ViewPostImeInputStage.processPointerEvent(ViewRootImpl.java:4688)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.ViewRootImpl$ViewPostImeInputStage.onProcess(ViewRootImpl.java:4576)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.ViewRootImpl$InputStage.deliver(ViewRootImpl.java:4170)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.ViewRootImpl$InputStage.onDeliverToNext(ViewRootImpl.java:4227)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.ViewRootImpl$InputStage.forward(ViewRootImpl.java:4196)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.ViewRootImpl$AsyncInputStage.forward(ViewRootImpl.java:4281)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.ViewRootImpl$InputStage.apply(ViewRootImpl.java:4204)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.ViewRootImpl$AsyncInputStage.apply(ViewRootImpl.java:4338)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.ViewRootImpl$InputStage.deliver(ViewRootImpl.java:4170)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.ViewRootImpl$InputStage.onDeliverToNext(ViewRootImpl.java:4227)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.ViewRootImpl$InputStage.forward(ViewRootImpl.java:4196)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.ViewRootImpl$InputStage.apply(ViewRootImpl.java:4204)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.ViewRootImpl$InputStage.deliver(ViewRootImpl.java:4170)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.ViewRootImpl.deliverInputEvent(ViewRootImpl.java:6330)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.ViewRootImpl.doProcessInputEvents(ViewRootImpl.java:6268)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.ViewRootImpl.enqueueInputEvent(ViewRootImpl.java:6239)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.ViewRootImpl$WindowInputEventReceiver.onInputEvent(ViewRootImpl.java:6410)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.view.InputEventReceiver.dispatchInputEvent(InputEventReceiver.java:188)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.os.MessageQueue.nativePollOnce(Native Method)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.os.MessageQueue.next(MessageQueue.java:132)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.os.Looper.loop(Looper.java:124)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at android.app.ActivityThread.main(ActivityThread.java:5493)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at java.lang.reflect.Method.invokeNative(Native Method)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at java.lang.reflect.Method.invoke(Method.java:525)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at com.android.internal.os.ZygoteInit$MethodAndArgsCaller.run(ZygoteInit.java:1209)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at com.android.internal.os.ZygoteInit.main(ZygoteInit.java:1025)
//02-19 15:44:47.528: E/MessageQueue-JNI(23737): 	at dalvik.system.NativeStart.main(Native Method)
//02-19 15:44:47.528: D/AndroidRuntime(23737): Shutting down VM
//02-19 15:44:47.528: W/dalvikvm(23737): threadid=1: thread exiting with uncaught exception (group=0x421f5700)
//02-19 15:44:47.538: E/AndroidRuntime(23737): FATAL EXCEPTION: main
//02-19 15:44:47.538: E/AndroidRuntime(23737): java.lang.NullPointerException
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at lia.db.DBManager.release(DBManager.java:52)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at com.vsquare.boothapp.page.ViewPage.onUnbind(ViewPage.java:520)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at lia.component.PageLayout.unBindAt(PageLayout.java:467)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at lia.component.PageLayout.changePage(PageLayout.java:291)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at lia.component.PageLayout.setIndexWithoutTabInPageLayout(PageLayout.java:284)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at lia.component.PageLayout.setIndexWithoutTabInPageLayout(PageLayout.java:249)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at lia.component.PageLayout.setIndexWithoutTab(PageLayout.java:244)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at lia.component.Tab.setIndex(Tab.java:76)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at lia.component.ButtonTab.setIndex(ButtonTab.java:66)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at lia.component.ButtonTab$1.onClick(ButtonTab.java:30)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at lia.component.ImageButton.onTouchEvent(ImageButton.java:198)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.View.dispatchTouchEvent(View.java:7831)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.ViewGroup.dispatchTransformedTouchEvent(ViewGroup.java:2441)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.ViewGroup.dispatchTouchEvent(ViewGroup.java:2174)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.ViewGroup.dispatchTransformedTouchEvent(ViewGroup.java:2441)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.ViewGroup.dispatchTouchEvent(ViewGroup.java:2174)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.ViewGroup.dispatchTransformedTouchEvent(ViewGroup.java:2441)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.ViewGroup.dispatchTouchEvent(ViewGroup.java:2174)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.ViewGroup.dispatchTransformedTouchEvent(ViewGroup.java:2441)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.ViewGroup.dispatchTouchEvent(ViewGroup.java:2174)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.ViewGroup.dispatchTransformedTouchEvent(ViewGroup.java:2441)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.ViewGroup.dispatchTouchEvent(ViewGroup.java:2174)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at com.android.internal.policy.impl.PhoneWindow$DecorView.superDispatchTouchEvent(PhoneWindow.java:2326)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at com.android.internal.policy.impl.PhoneWindow.superDispatchTouchEvent(PhoneWindow.java:1612)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.app.Activity.dispatchTouchEvent(Activity.java:2494)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at com.android.internal.policy.impl.PhoneWindow$DecorView.dispatchTouchEvent(PhoneWindow.java:2274)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.View.dispatchPointerEvent(View.java:8039)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.ViewRootImpl$ViewPostImeInputStage.processPointerEvent(ViewRootImpl.java:4688)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.ViewRootImpl$ViewPostImeInputStage.onProcess(ViewRootImpl.java:4576)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.ViewRootImpl$InputStage.deliver(ViewRootImpl.java:4170)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.ViewRootImpl$InputStage.onDeliverToNext(ViewRootImpl.java:4227)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.ViewRootImpl$InputStage.forward(ViewRootImpl.java:4196)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.ViewRootImpl$AsyncInputStage.forward(ViewRootImpl.java:4281)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.ViewRootImpl$InputStage.apply(ViewRootImpl.java:4204)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.ViewRootImpl$AsyncInputStage.apply(ViewRootImpl.java:4338)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.ViewRootImpl$InputStage.deliver(ViewRootImpl.java:4170)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.ViewRootImpl$InputStage.onDeliverToNext(ViewRootImpl.java:4227)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.ViewRootImpl$InputStage.forward(ViewRootImpl.java:4196)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.ViewRootImpl$InputStage.apply(ViewRootImpl.java:4204)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.ViewRootImpl$InputStage.deliver(ViewRootImpl.java:4170)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.ViewRootImpl.deliverInputEvent(ViewRootImpl.java:6330)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.ViewRootImpl.doProcessInputEvents(ViewRootImpl.java:6268)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.ViewRootImpl.enqueueInputEvent(ViewRootImpl.java:6239)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.ViewRootImpl$WindowInputEventReceiver.onInputEvent(ViewRootImpl.java:6410)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.view.InputEventReceiver.dispatchInputEvent(InputEventReceiver.java:188)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.os.MessageQueue.nativePollOnce(Native Method)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.os.MessageQueue.next(MessageQueue.java:132)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.os.Looper.loop(Looper.java:124)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at android.app.ActivityThread.main(ActivityThread.java:5493)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at java.lang.reflect.Method.invokeNative(Native Method)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at java.lang.reflect.Method.invoke(Method.java:525)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at com.android.internal.os.ZygoteInit$MethodAndArgsCaller.run(ZygoteInit.java:1209)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at com.android.internal.os.ZygoteInit.main(ZygoteInit.java:1025)
//02-19 15:44:47.538: E/AndroidRuntime(23737): 	at dalvik.system.NativeStart.main(Native Method)
