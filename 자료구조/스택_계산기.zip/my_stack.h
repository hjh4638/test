﻿/*
작성자 : 함준혁
학번 : 2010709159
*/
#include <cassert>

template <typename Item>
class Mystack {
public:
	//node를 구조체로 구현
	typedef struct node_t{
		Item key;
		struct node_t *next;
	};

	node_t *head = NULL;
	node_t *tail = NULL;
	size_t used;

	Mystack(){
		used = 0;
	}
	
	void push(const Item entry){
		node_t *new_node = new node_t;
		new_node->key = entry;
		new_node->next = NULL; 
		used++;
		if (head == NULL) {
			head = new_node;
			tail = new_node;
		}
		else {
			tail->next = new_node;
			tail = new_node;
		}
	}
	//n번째 노드를 리턴하는 함수
	node_t* locate(size_t n){
		node_t* node=head;
		if (n == 0){
			return NULL;
		}
		for (int i = 0; i < n-1; i++){
			node = node->next;
		}
		return node;
	}
	int pop(){
		node_t *node;
		node_t *node2 = locate(size()-1);
		int r;
		if (empty()) 
			return -1;
		used--;
		node = tail;
		tail = node2;
		if (tail != NULL)
			tail->next = NULL;
		else
			head = NULL;

		
		delete(node); 
		return 1;
	}
	//전체 노드 중 key가 n인 값이 있으면 true, 아니면 false 반환
	bool contain(Item n){
		node_t* node;
		for (int i = 1; i <= size(); i++){
			node = locate(i);
			if (node->key == n){
				return true;
			}
		}
		return false;
	}
	Item top() const{
		assert(!empty());
		return tail->key;
	}
	bool empty() const{
		return used == 0;
	}
	size_t size() const{
		return used;
	}
};