/*
�ۼ��� : ������
�й� : 2010709159
*/
#include <iostream>
using namespace std;

//�迭�� 0���� �ʱ�ȭ ���ִ� �Լ�
void reset(int n, int* a) {
	for (int index = 0; index < n; index++) {
		a[index] = 0;
	}
}

void findMaxMinSubMatrix(int n, int** matrix, int flag){
	int dim = n;

	int** ps = new int*[dim];
	for (int i = 0; i < dim; i++){
		ps[i] = new int[dim];
	}
	for (int i = 0; i < dim; i++) {
		for (int j = 0; j < dim; j++) {
			if (j == 0) {
				ps[j][i] = matrix[j][i];
			}
			else {
				ps[j][i] = matrix[j][i] + ps[j - 1][i];
			}
		}
	}

	int maxSum = matrix[0][0];
	int top = 0, left = 0, bottom = 0, right = 0;

	int* sum = new int[dim];
	int* pos = new int[dim];
	int localMax;

	for (int i = 0; i < dim; i++) {
		for (int k = i; k < dim; k++) {
			reset(dim,sum);
			reset(dim,pos);
			localMax = 0;
			sum[0] = ps[k][0] - (i == 0 ? 0 : ps[i - 1][0]);
			for (int j = 1; j < dim; j++) {
				if (sum[j - 1] > 0){
					sum[j] = sum[j - 1] + ps[k][j] - (i == 0 ? 0 : ps[i - 1][j]);
					pos[j] = pos[j - 1];
				}
				else{
					sum[j] = ps[k][j] - (i == 0 ? 0 : ps[i - 1][j]);
					pos[j] = j;
				}
				if (sum[j] > sum[localMax]){
					localMax = j;
				}
			}

			if (sum[localMax] > maxSum){
				maxSum = sum[localMax];
				top = i;
				left = pos[localMax];
				bottom = k;
				right = localMax;
			}
		}
	}
	if (flag == 1){
		maxSum = -1 * maxSum;
	}
	cout << maxSum << endl;
	cout << "(" << top << "," << left << ")" << " (" << bottom << "," << right << ")" ;
	
}


int main(){

	//�Է� �޴� �κ�
	int n;
	cin >> n;
	int** input = new int*[n];
	int** input2 = new int*[n];
	for (int i = 0; i < n; i++){
		input[i] = new int[n];
		input2[i] = new int[n];
	}
	for (int i = 0; i < n; i++){
		for (int j = 0; j < n; j++){
			cin >> input[i][j];
			input2[i][j] = -input[i][j];
		}
	}

	findMaxMinSubMatrix(n, input , 0);
	cout << endl;
	findMaxMinSubMatrix(n, input2 , 1);
	cout << endl;

	return 0;
}